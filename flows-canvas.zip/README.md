# Flows Canvas — drop-in React component

A fully self-contained React Flow canvas for AI video/image generation workflows.

---

## 1. Install dependencies

```bash
# npm
npm install @xyflow/react lucide-react clsx tailwind-merge

# pnpm
pnpm add @xyflow/react lucide-react clsx tailwind-merge
```

If you use Tailwind CSS (recommended), also ensure `tailwindcss` is set up.
The canvas components use standard Tailwind utility classes.

---

## 2. Copy the files

Drop the entire `flows-canvas/` folder anywhere inside your project's `src/`:

```
src/
  flows-canvas/        ← paste here
    canvas-editor.tsx
    header.tsx
    toolbar.tsx
    templates-panel.tsx
    templates.ts
    utils.ts
    canvas-theme.css
    nodes/
      index.ts
      base-node.tsx
      custom-nodes.tsx
    ui/
      button.tsx
      badge.tsx
      input.tsx
      scroll-area.tsx
      textarea.tsx
      dropdown-menu.tsx
      sheet.tsx
```

---

## 3. Add the CSS

Import `canvas-theme.css` once, near the top of your app (e.g. `main.tsx` / `index.tsx`):

```ts
import './flows-canvas/canvas-theme.css';
// also import React Flow's own stylesheet:
import '@xyflow/react/dist/style.css';
```

If you already have a dark theme and CSS variables set up, you may only need the
React Flow handle/edge overrides from the bottom half of `canvas-theme.css`.

---

## 4. Use the component

```tsx
import { CanvasEditor } from './flows-canvas/canvas-editor';

export default function MyPage() {
  return (
    // Give it a fixed height — the canvas fills 100% of its container
    <div style={{ height: '100vh' }}>
      <CanvasEditor />
    </div>
  );
}
```

That's it. The canvas renders with the default template and is fully interactive.

---

## 5. Tailwind config (if using Tailwind v3)

Add the canvas folder to your `content` array so Tailwind scans it:

```js
// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{ts,tsx}',
    // already covered by the glob above — no extra entry needed
  ],
  darkMode: 'class',
  // ...
};
```

Then add `dark` to your root element so the dark styles apply:
```ts
document.documentElement.classList.add('dark');
```

Or wrap the component in the included `ThemeProvider` if you copy it over too.

---

## Tailwind v4

If your project uses Tailwind v4 (`@import 'tailwindcss'`), add this to your
global CSS so the token aliases resolve:

```css
@theme inline {
  --color-background:  hsl(var(--background));
  --color-foreground:  hsl(var(--foreground));
  --color-border:      hsl(var(--border));
  --color-card:        hsl(var(--card));
  --color-card-foreground: hsl(var(--card-foreground));
  --color-primary:     hsl(var(--primary));
  --color-primary-foreground: hsl(var(--primary-foreground));
  --color-secondary:   hsl(var(--secondary));
  --color-secondary-foreground: hsl(var(--secondary-foreground));
  --color-muted:       hsl(var(--muted));
  --color-muted-foreground: hsl(var(--muted-foreground));
  --color-accent:      hsl(var(--accent));
  --color-accent-foreground: hsl(var(--accent-foreground));
  --color-destructive: hsl(var(--destructive));
  --color-destructive-foreground: hsl(var(--destructive-foreground));
  --color-input:       hsl(var(--input));
  --color-ring:        hsl(var(--ring));
  --color-popover:     hsl(var(--popover));
  --color-popover-foreground: hsl(var(--popover-foreground));
  --radius-sm: calc(var(--radius) - 4px);
  --radius-md: calc(var(--radius) - 2px);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) + 4px);
}
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Canvas is invisible / 0px height | Wrap in a `div` with an explicit height (`100vh`, `600px`, etc.) |
| Nodes have no background color | CSS variables not loaded — check `canvas-theme.css` is imported |
| `cn is not a function` | Make sure `utils.ts` is in the same folder as the components |
| Type errors on `@xyflow/react` | Run `npm install @xyflow/react` and restart TS server |
| Stale/amber UI | You have an old copy — replace with these files entirely |
