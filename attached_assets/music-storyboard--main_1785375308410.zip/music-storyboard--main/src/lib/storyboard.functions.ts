import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export type Shot = {
  id: string;
  board_id: string;
  position: number;
  title: string;
  shot_type: string | null;
  frame: string | null;
  wardrobe: string | null;
  mood: string | null;
  note: string | null;
  prompt: string | null;
  image_url: string | null;
  video_url: string | null;
  duration_seconds: number;
  scene: string;
};

export type Board = {
  id: string;
  title: string;
  treatment: string | null;
  style_preset: string;
  updated_at: string;
};

export type Character = {
  id: string;
  name: string;
  description: string | null;
  wardrobe: string | null;
  signature_props: string | null;
  reference_images: string[];
};

// -------- Boards --------
export const listBoards = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("boards")
      .select("id,title,treatment,style_preset,updated_at")
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as Board[];
  });

export const getBoard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => z.object({ boardId: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const [{ data: board, error: bErr }, { data: shots, error: sErr }, { data: chars, error: cErr }] =
      await Promise.all([
        context.supabase.from("boards").select("*").eq("id", data.boardId).single(),
        context.supabase.from("shots").select("*").eq("board_id", data.boardId).order("position"),
        context.supabase.from("characters").select("*").order("created_at"),
      ]);
    if (bErr) throw new Error(bErr.message);
    if (sErr) throw new Error(sErr.message);
    if (cErr) throw new Error(cErr.message);
    return {
      board: board as Board,
      shots: (shots ?? []) as Shot[],
      characters: (chars ?? []) as Character[],
    };
  });

export const createBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) =>
    z.object({ title: z.string().min(1).max(120).default("Untitled storyboard") }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("boards")
      .insert({ user_id: context.userId, title: data.title })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id as string };
  });

export const deleteBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("boards").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const renameBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) =>
    z.object({ id: z.string().uuid(), title: z.string().min(1).max(120) }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("boards").update({ title: data.title }).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// -------- Shots --------
const ShotPatch = z.object({
  title: z.string().max(200).optional(),
  shot_type: z.string().max(120).nullable().optional(),
  frame: z.string().max(200).nullable().optional(),
  wardrobe: z.string().max(400).nullable().optional(),
  mood: z.string().max(200).nullable().optional(),
  note: z.string().max(2000).nullable().optional(),
  prompt: z.string().max(4000).nullable().optional(),
  image_url: z.string().nullable().optional(),
  video_url: z.string().nullable().optional(),
  duration_seconds: z.number().min(0.5).max(60).optional(),
  scene: z.string().max(60).optional(),
  position: z.number().int().optional(),
});

export const createShot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) =>
    z
      .object({
        boardId: z.string().uuid(),
        patch: ShotPatch.default({}),
      })
      .parse(i),
  )
  .handler(async ({ data, context }) => {
    const { data: countRow } = await context.supabase
      .from("shots")
      .select("position")
      .eq("board_id", data.boardId)
      .order("position", { ascending: false })
      .limit(1)
      .maybeSingle();
    const nextPos = ((countRow?.position as number | undefined) ?? -1) + 1;
    const { data: row, error } = await context.supabase
      .from("shots")
      .insert({
        user_id: context.userId,
        board_id: data.boardId,
        position: nextPos,
        title: data.patch.title ?? "New shot",
        shot_type: data.patch.shot_type ?? null,
        frame: data.patch.frame ?? null,
        wardrobe: data.patch.wardrobe ?? null,
        mood: data.patch.mood ?? null,
        note: data.patch.note ?? null,
        prompt: data.patch.prompt ?? null,
        scene: data.patch.scene ?? "Verse",
        duration_seconds: data.patch.duration_seconds ?? 4,
      })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return row as Shot;
  });

export const updateShot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) =>
    z.object({ id: z.string().uuid(), patch: ShotPatch }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("shots").update(data.patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteShot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("shots").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const reorderShots = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) =>
    z.object({ order: z.array(z.object({ id: z.string().uuid(), position: z.number().int() })) }).parse(i),
  )
  .handler(async ({ data, context }) => {
    for (const row of data.order) {
      await context.supabase.from("shots").update({ position: row.position }).eq("id", row.id);
    }
    return { ok: true };
  });

// -------- Characters --------
const CharacterPatch = z.object({
  name: z.string().min(1).max(120),
  description: z.string().max(2000).nullable().optional(),
  wardrobe: z.string().max(1000).nullable().optional(),
  signature_props: z.string().max(1000).nullable().optional(),
  reference_images: z.array(z.string()).default([]),
});

export const upsertCharacter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) =>
    z.object({ id: z.string().uuid().optional(), patch: CharacterPatch }).parse(i),
  )
  .handler(async ({ data, context }) => {
    if (data.id) {
      const { error } = await context.supabase
        .from("characters")
        .update(data.patch)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase
      .from("characters")
      .insert({ ...data.patch, user_id: context.userId })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id as string };
  });

export const deleteCharacter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("characters").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Ensure the user has a default board seeded with demo shots the first time
// they open the studio.
const SEED_SHOTS: Array<{ title: string; shot_type: string; frame: string; wardrobe: string; mood: string; note: string; scene: string }> = [
  { title: "Ocean Drive Pull-Up", shot_type: "hero opener", frame: "Low rolling side shot", wardrobe: "Pink hoodie, black utility vest, red shades", mood: "Neon, humid, high-status", note: "Establishing flex shot before the verse lands.", scene: "Intro" },
  { title: "Blue Voltage", shot_type: "editorial profile", frame: "Locked-off profile medium", wardrobe: "Black leather jacket, white tee, heavy chains", mood: "Electric, fashion-forward", note: "Transition bars, slow intro with light flicker.", scene: "Intro" },
  { title: "Red Lens Close-Up", shot_type: "beauty detail", frame: "Extreme close-up", wardrobe: "Signature shades, pendant, dark tee", mood: "Intense, iconic", note: "Cut on punchlines for a signature face card moment.", scene: "Verse" },
  { title: "Rooftop Sunrise", shot_type: "anthem frame", frame: "Wide hero silhouette", wardrobe: "Red puffer, black tee, hood up", mood: "Triumphant, cinematic", note: "Hook or first chorus with skyline movement.", scene: "Chorus" },
  { title: "Taxi Crosswalk", shot_type: "fashion walk", frame: "Center walk-in wide", wardrobe: "Yellow puffer, black tee, red shades", mood: "Fast, urban, designer", note: "Speed ramps — traffic faster than the subject.", scene: "Verse" },
  { title: "Subway Silence", shot_type: "back-view mood", frame: "Symmetrical back shot", wardrobe: "Blue puffer, hood up", mood: "Icy, suspenseful", note: "Bridge or beat switch.", scene: "Bridge" },
  { title: "Courtside Dusk", shot_type: "product hero", frame: "Low sneaker-led angle", wardrobe: "Black hoodie, sneakers, chain", mood: "Sport-luxury, grounded", note: "Sells the sneaker story without losing identity.", scene: "Verse" },
  { title: "Pink Mic Attack", shot_type: "performance close-up", frame: "Aggressive tight performance", wardrobe: "Black graphic tee, rings, signature shades", mood: "Loud, playful", note: "Ad-libs, hooks, lyric overlays.", scene: "Chorus" },
  { title: "Back Alley Smoke", shot_type: "street noir", frame: "High angle wide", wardrobe: "Leather jacket, brown denim, wheat boots", mood: "Gritty, nocturnal", note: "Story beat between glamour scenes.", scene: "Bridge" },
  { title: "Walkout to Chaos", shot_type: "finale moment", frame: "Runway-style crowd push", wardrobe: "Purple track jacket, washed jeans", mood: "Victory lap, star power", note: "Closing ascent or last chorus payoff.", scene: "Outro" },
];

export const ensureDefaultBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: existing } = await context.supabase
      .from("boards")
      .select("id")
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (existing?.id) return { id: existing.id as string, seeded: false };
    const { data: board, error } = await context.supabase
      .from("boards")
      .insert({ user_id: context.userId, title: "My first storyboard", style_preset: "miami-neon" })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    const rows = SEED_SHOTS.map((s, i) => ({
      ...s,
      position: i,
      board_id: board.id as string,
      user_id: context.userId,
      duration_seconds: 4,
    }));
    await context.supabase.from("shots").insert(rows);
    return { id: board.id as string, seeded: true };
  });