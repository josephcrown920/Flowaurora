import { createFileRoute } from "@tanstack/react-router";
import { StudioPage } from "@/features/storyboard/studio/StudioPage";

export const Route = createFileRoute("/_authenticated/studio")({
  head: () => ({
    meta: [
      { title: "Studio · Storyboard" },
      { name: "description", content: "Design, direct, and generate your music video storyboard." },
    ],
  }),
  component: StudioPage,
});