import { createFileRoute } from "@tanstack/react-router";
import { Landing } from "@/features/storyboard/Landing";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Music Video Storyboard Shots" },
      {
        name: "description",
        content:
          "Ten cinematic storyboard frames blending neon Miami, studio portraiture, streetwear fashion, and performance energy.",
      },
      { property: "og:title", content: "Music Video Storyboard Shots" },
      {
        property: "og:description",
        content:
          "Ten cinematic storyboard frames blending neon Miami, studio portraiture, streetwear fashion, and performance energy.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});
