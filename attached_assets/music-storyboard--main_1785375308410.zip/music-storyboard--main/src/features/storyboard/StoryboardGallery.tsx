import { shots, type Shot } from "./shots";

type Props = {
  title?: string;
  subtitle?: string;
  data?: Shot[];
  showHero?: boolean;
};

export function StoryboardGallery({
  title = "Music video shot deck built from your avatar and reference looks.",
  subtitle = "A mixed-vibe sequence pulling from Miami neon nights, studio fashion portraits, gritty street frames, and performance setups so you can map the visual arc before production.",
  data = shots,
  showHero = true,
}: Props) {
  return (
    <main className="storyboard-shell">
      <div className="storyboard-wrap">
        {showHero && (
          <section className="storyboard-hero">
            <div className="grid gap-5">
              <span className="storyboard-kicker">Storyboard · {data.length} generated frames</span>
              <h1 className="storyboard-title">{title}</h1>
              <p className="storyboard-subtitle">{subtitle}</p>
            </div>

            <div className="storyboard-meta-grid" aria-label="Storyboard details">
              <div className="storyboard-stat">
                <span className="storyboard-stat-label">Shots</span>
                <p className="storyboard-stat-value">{data.length} distinct frames</p>
              </div>
              <div className="storyboard-stat">
                <span className="storyboard-stat-label">Palette</span>
                <p className="storyboard-stat-value">Neon red, royal blue, hot pink, gold rain</p>
              </div>
              <div className="storyboard-stat">
                <span className="storyboard-stat-label">Mix</span>
                <p className="storyboard-stat-value">Performance, fashion, city narrative</p>
              </div>
              <div className="storyboard-stat">
                <span className="storyboard-stat-label">Use</span>
                <p className="storyboard-stat-value">Sequence planning, lookbook, shot-list kickoff</p>
              </div>
            </div>
          </section>
        )}

        <section aria-labelledby="storyboard-grid-title">
          <div className="storyboard-section-head">
            <div className="grid gap-2">
              <h2 id="storyboard-grid-title" className="storyboard-section-title">
                Storyboard gallery
              </h2>
              <p className="storyboard-section-copy">
                Each frame includes a suggested camera language, outfit cue, and emotional purpose so the set pieces
                feel connected when you sequence the video.
              </p>
            </div>
          </div>

          <div className="storyboard-grid">
            {data.map((shot) => (
              <article key={shot.id} className="storyboard-card">
                <img className="storyboard-shot-image" src={shot.image} alt={shot.alt} loading="lazy" />
                <div className="storyboard-card-body">
                  <div className="storyboard-card-topline">
                    <span className="storyboard-shot-number">Shot {shot.id}</span>
                    <span className="storyboard-shot-type">{shot.type}</span>
                  </div>

                  <div className="grid gap-2">
                    <h3 className="storyboard-card-title">{shot.title}</h3>
                    <p className="storyboard-card-copy">{shot.note}</p>
                  </div>

                  <div className="storyboard-pill-row" aria-label={`Details for shot ${shot.id}`}>
                    <span className="storyboard-pill">{shot.frame}</span>
                    <span className="storyboard-pill">{shot.wardrobe}</span>
                    <span className="storyboard-pill">{shot.mood}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <p className="storyboard-footer-note">
          Next step: turn these frames into a tighter sequence with scene order, transitions, and matching performance
          setups for each song section.
        </p>
      </div>
    </main>
  );
}

export { shots };
export type { Shot };