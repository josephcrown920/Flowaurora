import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoryboardGallery } from "./StoryboardGallery";

export function Landing() {
  const navigate = useNavigate();
  const [authed, setAuthed] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setAuthed(!!data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setAuthed(!!session?.user);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 border-b border-border/60 backdrop-blur bg-background/80">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <span className="font-semibold tracking-tight">Storyboard Studio</span>
          <nav className="flex items-center gap-3 text-sm">
            <a href="#gallery" className="text-muted-foreground hover:text-foreground">
              Preview
            </a>
            {authed ? (
              <button
                onClick={() => navigate({ to: "/studio" })}
                className="rounded-md bg-primary text-primary-foreground px-3 py-1.5 font-medium"
              >
                Open studio →
              </button>
            ) : (
              <>
                <Link to="/auth" className="text-muted-foreground hover:text-foreground">
                  Sign in
                </Link>
                <Link
                  to="/auth"
                  className="rounded-md bg-primary text-primary-foreground px-3 py-1.5 font-medium"
                >
                  Get started
                </Link>
              </>
            )}
          </nav>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 pt-16 pb-10">
        <p className="text-xs uppercase tracking-[0.2em] text-accent">AI Music Video Studio</p>
        <h1 className="mt-4 text-5xl md:text-6xl font-semibold leading-tight">
          Storyboard your music video with an AI director on set.
        </h1>
        <p className="mt-4 max-w-2xl text-lg text-muted-foreground">
          A canvas for shots, a timeline for pacing, character sheets that keep your look consistent,
          and streaming image generation — powered by Lovable AI.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => navigate({ to: authed ? "/studio" : "/auth" })}
            className="rounded-md bg-primary text-primary-foreground px-5 py-3 font-medium"
          >
            {authed ? "Open your studio" : "Start a storyboard"}
          </button>
          <a
            href="#gallery"
            className="rounded-md border border-border px-5 py-3 font-medium hover:bg-accent hover:text-accent-foreground"
          >
            See a sample
          </a>
        </div>
      </section>

      <section id="gallery" className="border-t border-border/60">
        <StoryboardGallery />
      </section>
    </div>
  );
}