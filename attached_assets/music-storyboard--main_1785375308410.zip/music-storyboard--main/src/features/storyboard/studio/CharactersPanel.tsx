import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { deleteCharacter, upsertCharacter, type Character } from "@/lib/storyboard.functions";

export function CharactersPanel({
  characters,
  refresh,
}: {
  characters: Character[];
  refresh: () => void;
}) {
  const upsertFn = useServerFn(upsertCharacter);
  const deleteFn = useServerFn(deleteCharacter);
  const [editing, setEditing] = useState<Partial<Character> | null>(null);

  const save = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          id: editing?.id,
          patch: {
            name: editing?.name || "Unnamed",
            description: editing?.description ?? null,
            wardrobe: editing?.wardrobe ?? null,
            signature_props: editing?.signature_props ?? null,
            reference_images: editing?.reference_images ?? [],
          },
        },
      }),
    onSuccess: () => {
      setEditing(null);
      refresh();
    },
  });

  return (
    <div className="flex-1 grid grid-cols-[1fr_360px] min-h-0">
      <section className="p-6 overflow-auto">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-xs uppercase tracking-widest text-muted-foreground">Character sheets</span>
            <h2 className="text-lg font-semibold">Cast &amp; wardrobe</h2>
          </div>
          <button
            onClick={() => setEditing({})}
            className="rounded-md bg-primary text-primary-foreground px-3 py-1.5 text-sm font-medium"
          >
            + New character
          </button>
        </div>
        {characters.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Add your artist or supporting cast so the Director can reference them consistently.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {characters.map((c) => (
              <div key={c.id} className="rounded-xl border border-border bg-card p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{c.name}</div>
                  <div className="flex gap-2 text-xs">
                    <button onClick={() => setEditing(c)} className="hover:underline">
                      Edit
                    </button>
                    <button
                      onClick={async () => {
                        if (!confirm("Delete this character?")) return;
                        await deleteFn({ data: { id: c.id } });
                        refresh();
                      }}
                      className="text-destructive hover:underline"
                    >
                      Delete
                    </button>
                  </div>
                </div>
                {c.description && <p className="text-sm text-muted-foreground">{c.description}</p>}
                {c.wardrobe && (
                  <p className="text-xs">
                    <span className="text-muted-foreground">Wardrobe: </span>
                    {c.wardrobe}
                  </p>
                )}
                {c.signature_props && (
                  <p className="text-xs">
                    <span className="text-muted-foreground">Signature: </span>
                    {c.signature_props}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <aside className="border-l border-border/60 p-5 overflow-auto space-y-3">
        <span className="text-xs uppercase tracking-widest text-muted-foreground">
          {editing ? (editing.id ? "Edit character" : "New character") : "Editor"}
        </span>
        {!editing ? (
          <p className="text-sm text-muted-foreground">Select or add a character.</p>
        ) : (
          <div className="space-y-3">
            <Input
              label="Name"
              value={editing.name ?? ""}
              onChange={(v) => setEditing({ ...editing, name: v })}
            />
            <TextArea
              label="Description"
              value={editing.description ?? ""}
              onChange={(v) => setEditing({ ...editing, description: v })}
            />
            <TextArea
              label="Wardrobe"
              value={editing.wardrobe ?? ""}
              onChange={(v) => setEditing({ ...editing, wardrobe: v })}
            />
            <TextArea
              label="Signature props"
              value={editing.signature_props ?? ""}
              onChange={(v) => setEditing({ ...editing, signature_props: v })}
            />
            <div className="flex gap-2">
              <button
                onClick={() => save.mutate()}
                disabled={save.isPending || !editing.name}
                className="flex-1 rounded-md bg-primary text-primary-foreground px-3 py-2 text-sm font-medium disabled:opacity-60"
              >
                {save.isPending ? "Saving…" : "Save"}
              </button>
              <button
                onClick={() => setEditing(null)}
                className="rounded-md border border-border px-3 py-2 text-sm"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block space-y-1">
      <span className="text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
      />
    </label>
  );
}
function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block space-y-1">
      <span className="text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
      <textarea
        value={value}
        rows={3}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
      />
    </label>
  );
}