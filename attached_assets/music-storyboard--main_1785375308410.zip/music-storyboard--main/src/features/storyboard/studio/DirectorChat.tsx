import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { createShot, type Shot } from "@/lib/storyboard.functions";

export function DirectorChat({
  shots,
  boardId,
  onShotAdded,
}: {
  shots: Shot[];
  boardId: string;
  onShotAdded: () => void;
}) {
  const boardContext = shots
    .map((s, i) => `${i + 1}. ${s.title} — ${s.scene} — ${s.mood ?? ""} (${s.duration_seconds}s)`)
    .join("\n");

  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, status } = useChat({
    id: boardId,
    transport: new DefaultChatTransport({
      api: "/api/chat",
      body: () => ({ boardContext }),
    }),
  });

  const createFn = useServerFn(createShot);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function acceptProposal(input: any) {
    await createFn({
      data: {
        boardId,
        patch: {
          title: input.title,
          shot_type: input.shot_type,
          frame: input.frame,
          wardrobe: input.wardrobe,
          mood: input.mood,
          note: input.note,
          scene: input.scene,
          prompt: input.image_prompt,
        },
      },
    });
    onShotAdded();
  }

  const busy = status === "submitted" || status === "streaming";

  return (
    <div className="flex-1 grid grid-cols-1 min-h-0">
      <div className="flex flex-col min-h-0 max-w-3xl w-full mx-auto">
        <div className="p-4 border-b border-border/60">
          <span className="text-xs uppercase tracking-widest text-accent">Director</span>
          <h2 className="text-lg font-semibold">Chat with your AI collaborator</h2>
          <p className="text-sm text-muted-foreground">
            Ask for shot ideas, wardrobe tweaks, or pacing notes. Accept proposals to drop them onto the board.
          </p>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-sm text-muted-foreground">
              Try: <em>"Give me a rooftop closing shot with pink neon."</em>
            </div>
          )}
          {messages.map((m) => (
            <div key={m.id} className={"flex " + (m.role === "user" ? "justify-end" : "justify-start")}>
              <div
                className={
                  "max-w-[85%] rounded-2xl px-4 py-2.5 text-sm " +
                  (m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border")
                }
              >
                {m.parts.map((p, i) => {
                  if (p.type === "text") return <div key={i} className="whitespace-pre-wrap">{p.text}</div>;
                  if (p.type === "tool-propose_shot") {
                    const input: any = (p as any).input;
                    if (!input) return null;
                    return (
                      <div key={i} className="mt-2 rounded-xl border border-border bg-background text-foreground p-3 space-y-1">
                        <div className="text-xs uppercase tracking-widest text-accent">Proposed shot</div>
                        <div className="font-medium">{input.title}</div>
                        <div className="text-xs text-muted-foreground">
                          {input.scene} · {input.shot_type} · {input.mood}
                        </div>
                        <div className="text-xs">{input.note}</div>
                        <button
                          onClick={() => acceptProposal(input)}
                          className="mt-2 rounded-md bg-primary text-primary-foreground px-3 py-1.5 text-xs font-medium"
                        >
                          Add to storyboard
                        </button>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          ))}
          {busy && <div className="text-xs text-muted-foreground">Director is thinking…</div>}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const text = input.trim();
            if (!text || busy) return;
            sendMessage({ text });
            setInput("");
            requestAnimationFrame(() => inputRef.current?.focus());
          }}
          className="border-t border-border/60 p-3 flex gap-2"
        >
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                e.currentTarget.form?.requestSubmit();
              }
            }}
            rows={2}
            placeholder="Ask the Director…"
            className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm resize-none"
          />
          <button
            type="submit"
            disabled={busy}
            className="rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium disabled:opacity-60"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}