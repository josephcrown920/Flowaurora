import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import {
  createShot,
  deleteShot,
  ensureDefaultBoard,
  getBoard,
  reorderShots,
  updateShot,
  type Shot,
  type Character,
} from "@/lib/storyboard.functions";
import { streamImage } from "@/lib/streamImage";
import { CharactersPanel } from "./CharactersPanel";
import { DirectorChat } from "./DirectorChat";

type Tab = "shots" | "characters" | "chat";

export function StudioPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const ensureFn = useServerFn(ensureDefaultBoard);
  const getBoardFn = useServerFn(getBoard);

  const boardQ = useQuery({
    queryKey: ["board"],
    queryFn: async () => {
      const { id } = await ensureFn();
      return getBoardFn({ data: { boardId: id } });
    },
  });

  const [tab, setTab] = useState<Tab>("shots");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    if (boardQ.data?.shots?.length && !selectedId) setSelectedId(boardQ.data.shots[0].id);
  }, [boardQ.data, selectedId]);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (boardQ.isLoading || !boardQ.data) {
    return (
      <div className="min-h-screen grid place-items-center bg-background text-muted-foreground">
        Loading your studio…
      </div>
    );
  }

  const { board, shots, characters } = boardQ.data;
  const selected = shots.find((s) => s.id === selectedId) ?? null;

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="border-b border-border/60 px-4 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-xs uppercase tracking-[0.2em] text-accent">Studio</span>
          <h1 className="text-lg font-semibold">{board.title}</h1>
        </div>
        <div className="flex items-center gap-2">
          <TabBtn active={tab === "shots"} onClick={() => setTab("shots")}>Shots</TabBtn>
          <TabBtn active={tab === "characters"} onClick={() => setTab("characters")}>Characters</TabBtn>
          <TabBtn active={tab === "chat"} onClick={() => setTab("chat")}>Director</TabBtn>
          <button onClick={signOut} className="ml-2 text-xs text-muted-foreground hover:text-foreground">
            Sign out
          </button>
        </div>
      </header>

      {tab === "shots" && (
        <ShotsCanvas
          shots={shots}
          characters={characters}
          selected={selected}
          onSelect={setSelectedId}
          refresh={() => qc.invalidateQueries({ queryKey: ["board"] })}
          boardId={board.id}
        />
      )}
      {tab === "characters" && (
        <CharactersPanel
          characters={characters}
          refresh={() => qc.invalidateQueries({ queryKey: ["board"] })}
        />
      )}
      {tab === "chat" && (
        <DirectorChat
          shots={shots}
          boardId={board.id}
          onShotAdded={() => qc.invalidateQueries({ queryKey: ["board"] })}
        />
      )}
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={
        "rounded-md px-3 py-1.5 text-sm font-medium transition " +
        (active ? "bg-primary text-primary-foreground" : "hover:bg-accent hover:text-accent-foreground")
      }
    >
      {children}
    </button>
  );
}

function ShotsCanvas({
  shots,
  characters,
  selected,
  onSelect,
  refresh,
  boardId,
}: {
  shots: Shot[];
  characters: Character[];
  selected: Shot | null;
  onSelect: (id: string) => void;
  refresh: () => void;
  boardId: string;
}) {
  const createFn = useServerFn(createShot);
  const reorderFn = useServerFn(reorderShots);
  const create = useMutation({
    mutationFn: () => createFn({ data: { boardId, patch: {} } }),
    onSuccess: (row) => {
      onSelect(row.id);
      refresh();
    },
  });

  async function move(id: string, dir: -1 | 1) {
    const idx = shots.findIndex((s) => s.id === id);
    const swap = idx + dir;
    if (swap < 0 || swap >= shots.length) return;
    const a = shots[idx];
    const b = shots[swap];
    await reorderFn({
      data: {
        order: [
          { id: a.id, position: b.position },
          { id: b.id, position: a.position },
        ],
      },
    });
    refresh();
  }

  const totalDuration = useMemo(
    () => shots.reduce((acc, s) => acc + Number(s.duration_seconds || 0), 0),
    [shots],
  );

  return (
    <div className="flex-1 grid grid-cols-[1fr_360px] min-h-0">
      <section className="flex flex-col min-h-0">
        <div className="p-4 flex items-center justify-between border-b border-border/60">
          <div className="flex flex-col">
            <span className="text-xs uppercase tracking-widest text-muted-foreground">Canvas</span>
            <span className="text-sm text-muted-foreground">
              {shots.length} shots · {totalDuration.toFixed(1)}s runtime
            </span>
          </div>
          <button
            onClick={() => create.mutate()}
            disabled={create.isPending}
            className="rounded-md bg-primary text-primary-foreground px-3 py-1.5 text-sm font-medium disabled:opacity-60"
          >
            + New shot
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {shots.map((shot, i) => (
              <button
                key={shot.id}
                onClick={() => onSelect(shot.id)}
                className={
                  "text-left rounded-xl border overflow-hidden bg-card transition " +
                  (selected?.id === shot.id
                    ? "border-primary ring-2 ring-primary/40"
                    : "border-border hover:border-primary/50")
                }
              >
                <div className="aspect-video bg-muted/40 grid place-items-center overflow-hidden">
                  {shot.image_url ? (
                    <img src={shot.image_url} alt={shot.title} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-xs text-muted-foreground">No frame yet</span>
                  )}
                </div>
                <div className="p-3 space-y-1">
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>Shot {String(i + 1).padStart(2, "0")}</span>
                    <span>{shot.scene}</span>
                  </div>
                  <div className="font-medium">{shot.title}</div>
                  {shot.mood && <div className="text-xs text-muted-foreground">{shot.mood}</div>}
                  <div className="pt-2 flex items-center gap-1 text-xs">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        move(shot.id, -1);
                      }}
                      className="px-2 py-1 rounded hover:bg-accent hover:text-accent-foreground"
                    >
                      ↑
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        move(shot.id, 1);
                      }}
                      className="px-2 py-1 rounded hover:bg-accent hover:text-accent-foreground"
                    >
                      ↓
                    </button>
                    <span className="ml-auto text-muted-foreground">{shot.duration_seconds}s</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <Timeline shots={shots} selectedId={selected?.id ?? null} onSelect={onSelect} />
      </section>

      <aside className="border-l border-border/60 min-h-0 overflow-auto">
        {selected ? (
          <Inspector shot={selected} characters={characters} refresh={refresh} />
        ) : (
          <div className="p-6 text-sm text-muted-foreground">Select a shot to edit.</div>
        )}
      </aside>
    </div>
  );
}

function Timeline({
  shots,
  selectedId,
  onSelect,
}: {
  shots: Shot[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  const total = shots.reduce((a, s) => a + Number(s.duration_seconds || 0), 0);
  return (
    <div className="border-t border-border/60 bg-card/40 p-4">
      <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">
        Timeline · {total.toFixed(1)}s
      </div>
      <div className="flex gap-1 h-16 overflow-x-auto">
        {shots.map((s, i) => {
          const width = Math.max(60, (Number(s.duration_seconds) || 1) * 24);
          return (
            <button
              key={s.id}
              onClick={() => onSelect(s.id)}
              style={{ width }}
              className={
                "flex-shrink-0 rounded-md border overflow-hidden text-left text-xs transition " +
                (selectedId === s.id
                  ? "border-primary ring-1 ring-primary/40"
                  : "border-border hover:border-primary/50")
              }
            >
              <div className="h-8 bg-muted/60 relative overflow-hidden">
                {s.image_url && (
                  <img src={s.image_url} alt="" className="w-full h-full object-cover opacity-80" />
                )}
              </div>
              <div className="px-1.5 py-1 truncate">
                <span className="text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>{" "}
                {s.title}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Inspector({
  shot,
  characters,
  refresh,
}: {
  shot: Shot;
  characters: Character[];
  refresh: () => void;
}) {
  const updateFn = useServerFn(updateShot);
  const deleteFn = useServerFn(deleteShot);
  const [form, setForm] = useState(shot);
  const [saving, setSaving] = useState(false);
  const [genPreview, setGenPreview] = useState<string | null>(null);
  const [genFinal, setGenFinal] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    setForm(shot);
    setGenPreview(null);
    setGenFinal(false);
    setGenError(null);
  }, [shot.id]);

  function bind<K extends keyof Shot>(key: K) {
    return {
      value: (form[key] ?? "") as string,
      onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
        setForm((f) => ({ ...f, [key]: e.target.value })),
    };
  }

  async function save() {
    setSaving(true);
    try {
      await updateFn({
        data: {
          id: shot.id,
          patch: {
            title: form.title,
            shot_type: form.shot_type,
            frame: form.frame,
            wardrobe: form.wardrobe,
            mood: form.mood,
            note: form.note,
            prompt: form.prompt,
            scene: form.scene,
            duration_seconds: Number(form.duration_seconds) || 4,
          },
        },
      });
      refresh();
    } finally {
      setSaving(false);
    }
  }

  async function generate() {
    const prompt =
      form.prompt?.trim() ||
      [form.title, form.frame, form.wardrobe, form.mood, form.note].filter(Boolean).join(", ");
    if (!prompt) {
      setGenError("Add a prompt or fill in a few fields first.");
      return;
    }
    setGenerating(true);
    setGenError(null);
    setGenFinal(false);
    setGenPreview(null);
    try {
      let last = "";
      await streamImage("/api/generate-image", `Cinematic music video still: ${prompt}`, (url, isFinal) => {
        last = url;
        setGenPreview(url);
        setGenFinal(isFinal);
      });
      // Persist final image (data URL for MVP).
      await updateFn({ data: { id: shot.id, patch: { image_url: last } } });
      refresh();
    } catch (e) {
      setGenError(e instanceof Error ? e.message : "Generation failed");
    } finally {
      setGenerating(false);
    }
  }

  async function remove() {
    if (!confirm("Delete this shot?")) return;
    await deleteFn({ data: { id: shot.id } });
    refresh();
  }

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-widest text-muted-foreground">Inspector</span>
        <button onClick={remove} className="text-xs text-destructive hover:underline">
          Delete
        </button>
      </div>

      <div className="rounded-xl overflow-hidden border border-border bg-muted/30 aspect-video grid place-items-center">
        {genPreview ? (
          <img
            src={genPreview}
            alt=""
            className={"w-full h-full object-cover transition " + (genFinal ? "blur-0" : "blur-md")}
          />
        ) : shot.image_url ? (
          <img src={shot.image_url} alt="" className="w-full h-full object-cover" />
        ) : (
          <span className="text-xs text-muted-foreground">No frame yet</span>
        )}
      </div>

      <button
        onClick={generate}
        disabled={generating}
        className="w-full rounded-md bg-primary text-primary-foreground px-3 py-2 text-sm font-medium disabled:opacity-60"
      >
        {generating ? "Generating…" : shot.image_url ? "Regenerate frame" : "Generate frame with AI"}
      </button>
      {genError && <p className="text-xs text-destructive">{genError}</p>}

      <Field label="Title">
        <input {...bind("title")} className="input" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Scene">
          <input {...bind("scene")} className="input" />
        </Field>
        <Field label="Duration (s)">
          <input
            type="number"
            step="0.5"
            min="0.5"
            value={String(form.duration_seconds ?? "")}
            onChange={(e) => setForm((f) => ({ ...f, duration_seconds: Number(e.target.value) }))}
            className="input"
          />
        </Field>
      </div>
      <Field label="Shot type">
        <input {...bind("shot_type")} className="input" />
      </Field>
      <Field label="Frame / camera">
        <input {...bind("frame")} className="input" />
      </Field>
      <Field label="Wardrobe">
        <input {...bind("wardrobe")} className="input" />
      </Field>
      <Field label="Mood">
        <input {...bind("mood")} className="input" />
      </Field>
      <Field label="Director note">
        <textarea rows={3} {...bind("note")} className="input" />
      </Field>
      <Field label="Image prompt (optional)">
        <textarea
          rows={3}
          {...bind("prompt")}
          className="input"
          placeholder="Overrides the auto-built prompt when set."
        />
      </Field>

      <button
        onClick={save}
        disabled={saving}
        className="w-full rounded-md border border-border px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground disabled:opacity-60"
      >
        {saving ? "Saving…" : "Save changes"}
      </button>

      {characters.length > 0 && (
        <div className="pt-3 border-t border-border/60 text-xs text-muted-foreground">
          Character sheet:{" "}
          {characters.map((c) => c.name).join(", ")}
        </div>
      )}

      <style>{`.input { width: 100%; border-radius: 6px; border: 1px solid var(--border); background: var(--background); padding: 6px 10px; font-size: 13px; }`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1">
      <span className="text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}