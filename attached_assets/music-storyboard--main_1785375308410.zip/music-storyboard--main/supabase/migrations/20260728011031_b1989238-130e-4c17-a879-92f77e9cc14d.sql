
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;

-- Storage RLS: users can read/write their own folder in storyboard-media
CREATE POLICY "storyboard_media_owner_read" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'storyboard-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "storyboard_media_owner_write" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'storyboard-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "storyboard_media_owner_update" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'storyboard-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "storyboard_media_owner_delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'storyboard-media' AND (storage.foldername(name))[1] = auth.uid()::text);
