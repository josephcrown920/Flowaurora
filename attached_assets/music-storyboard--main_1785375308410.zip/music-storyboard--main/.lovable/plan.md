# Storyboard Studio — full build plan

Turn the current static gallery into a real storyboard tool with a canvas, timeline, character sheet, AI image + video generation, and an LLM director assistant. Boards, shots, and characters save to Lovable Cloud so nothing is lost between sessions, with a local-only fallback for guests.

## What you'll get

1. **Projects & persistence**
   - Sign in with email or Google.
   - "My storyboards" list, create/rename/delete boards.
   - Guests can play with a local demo board (localStorage); signing in migrates it to the cloud.

2. **Canvas (shot board)**
   - Zoomable/pannable board with draggable shot cards.
   - Each card shows the frame, title, shot type, mood pill, and a "Regenerate" button.
   - Right-side inspector to edit title, prompt, wardrobe, camera notes, character link.
   - Add / duplicate / delete / reorder shots. Multi-select drag.

3. **Timeline**
   - Bottom strip: shots in play order, each with a duration slider (0.5–20s) and scene grouping (Intro / Verse / Chorus / Bridge / Outro).
   - Total runtime readout + basic scrub preview (cross-fades between stills; plays generated clips inline if present).
   - Drag-to-reorder mirrors the canvas order.

4. **Character sheet**
   - Reusable characters (name, description, reference images, wardrobe presets, signature props).
   - Each shot can reference one or more characters — their description auto-injects into the image/video prompt so the avatar stays consistent.
   - Upload reference photos (stored in Cloud storage).

5. **AI image generation** (Lovable AI Gateway, streaming)
   - "Generate frame" on any shot uses `openai/gpt-image-2` with streaming partial previews (blurred → sharp).
   - Prompt = shot description + linked character sheet + global style preset (Miami neon / studio / street / performance).
   - Generated PNGs saved to Cloud storage, referenced on the shot.

6. **AI video clips** (opt-in per shot, higher cost)
   - "Animate this shot" turns the still into a 5s clip via the videogen path.
   - Clip attaches to the shot and plays in the timeline scrub.

7. **LLM director assistant**
   - Chat panel powered by `google/gemini-3.6-flash` via AI SDK + `useChat`.
   - Tools it can call: `add_shot`, `update_shot`, `reorder_shots`, `create_character`, `suggest_prompts_from_treatment`.
   - Paste a treatment / lyrics → it drafts a full 10-shot board you can accept.

## Technical layout

```text
src/
  routes/
    index.tsx                     → marketing landing + "Open studio"
    _authenticated/
      studio.tsx                  → studio shell (canvas + timeline + inspector + chat)
      boards.tsx                  → board list
    api/
      chat.ts                     → streamText, tools, gateway
      generate-image.ts           → SSE image stream
      generate-video.ts           → kicks off video job, returns URL
    auth.tsx                      → email + Google sign-in
  features/storyboard/
    canvas/ (Board, ShotCard, Inspector)
    timeline/ (Timeline, SceneGroup, Scrubber)
    characters/ (CharacterSheet, CharacterPicker)
    chat/ (DirectorChat)
    hooks/ (useBoard, useShots, useCharacters — cloud + local fallback)
    shots.ts                      → existing demo data becomes the seed board
  lib/
    ai-gateway.server.ts          → Lovable AI provider helper
    storyboard.functions.ts       → createServerFn CRUD (auth middleware)
```

DB tables (all RLS, owner = `auth.uid()`):
`boards`, `shots`, `characters`, `shot_characters`, plus a `storyboard-media` storage bucket for generated frames, clips, and character refs.

Server boundaries follow TanStack rules: streaming (`/api/chat`, `/api/generate-image`) uses server routes; CRUD uses `createServerFn` with `requireSupabaseAuth`.

## Ship order

1. **Phase 1 — Foundation**: enable Lovable Cloud, auth (email + Google), DB schema + RLS, migrate current 10 shots into a seed board, "My boards" list.
2. **Phase 2 — Canvas + Character sheet**: zoomable board, inspector, character CRUD, link characters to shots.
3. **Phase 3 — Timeline**: durations, scene groups, scrub preview.
4. **Phase 4 — AI image generation**: streaming `/api/generate-image`, save to storage, regenerate per shot with character-aware prompt.
5. **Phase 5 — LLM director chat**: `/api/chat` with tools that mutate the board.
6. **Phase 6 — AI video clips**: `/api/generate-video`, attach to shots, play in scrub.

Each phase is usable on its own — approve and I'll start Phase 1.

## Confirm before I build

- OK to enable **Lovable Cloud** now (needed for auth, DB, storage, generated media).
- Phase 1 first, or do you want me to run straight through all 6?
