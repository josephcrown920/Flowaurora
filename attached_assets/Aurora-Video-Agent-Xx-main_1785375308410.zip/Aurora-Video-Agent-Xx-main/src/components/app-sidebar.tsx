import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Images,
  Film,
  Mic,
  Move3d,
  Clapperboard,
  Bookmark,
  Library,
  Bot,
  Settings,
  Sparkles,
  Zap,
  Wand2,
  Edit3,
  Grid3x3,
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

const groups = [
  {
    label: "Video Agent",
    items: [
      { title: "Home", url: "/", icon: LayoutDashboard },
      { title: "Create Video", url: "/create", icon: Zap },
      { title: "Gallery", url: "/gallery", icon: Grid3x3 },
    ],
  },
  {
    label: "Studio Tools",
    items: [
      { title: "Images", url: "/playground", icon: Images },
      { title: "Videos", url: "/videos", icon: Film },
      { title: "Storyboard (Batch)", url: "/storyboard", icon: Clapperboard },
      { title: "Workflows", url: "/workflows", icon: Wand2 },
      { title: "Lip Sync", url: "/lip-sync", icon: Mic },
      { title: "Motion Control", url: "/motion-control", icon: Move3d },
    ],
  },
  {
    label: "Library",
    items: [
      { title: "Prompt Library", url: "/prompts", icon: Bookmark },
      { title: "References", url: "/references", icon: Library },
    ],
  },
  {
    label: "System",
    items: [
      { title: "AI Providers", url: "/providers", icon: Bot },
      { title: "Settings", url: "/settings", icon: Settings },
    ],
  },
];

export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isActive = (url: string) => (url === "/" ? pathname === "/" : pathname.startsWith(url));

  return (
    <Sidebar collapsible="icon" className="glass-strong">
      <SidebarHeader className="border-b border-sidebar-border/50">
        <div className="flex items-center gap-2 px-2 py-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary-glow glow">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          <div className="flex flex-col leading-tight group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-semibold tracking-tight">Aurora Agent</span>
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
              Video AI
            </span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        {groups.map((g) => (
          <SidebarGroup key={g.label}>
            <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {g.items.map((item) => (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={isActive(item.url)}>
                      <Link to={item.url} className="flex items-center gap-2">
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border/50">
        <div className="px-2 py-1 text-[10px] text-muted-foreground group-data-[collapsible=icon]:hidden">
          Aurora · Lovable AI Gateway
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
