// Local-first store for Studio: prompts (+versions), gallery, refs, motion, lipsync, videos.
export type GalleryItem = {
  id: string;
  prompt: string;
  dataUrl: string;
  createdAt: number;
  kind: "image" | "video";
};

export type PromptVersion = {
  id: string;
  body: string;
  title: string;
  createdAt: number;
};

export type PromptItem = {
  id: string;
  title: string;
  body: string;
  category: string;
  favorite: boolean;
  createdAt: number;
  updatedAt?: number;
  versions?: PromptVersion[];
};

export type ReferenceItem = {
  id: string;
  name: string;
  dataUrl: string;
  mime: string;
  tags: string[];
  selected?: boolean;
  createdAt: number;
};

export type MotionKeyframe = {
  id: string;
  time: number; // seconds
  prompt: string;
  refId?: string;
  imageUrl?: string;
  status?: "idle" | "loading" | "done" | "error";
};

export type MotionClip = {
  id: string;
  name: string;
  duration: number;
  camera: string;
  intensity: number;
  keyframes: MotionKeyframe[];
  createdAt: number;
};

export type LipSyncJob = {
  id: string;
  name: string;
  videoUrl: string;
  audioUrl: string | null;
  script: string;
  createdAt: number;
};

export type VideoClip = {
  id: string;
  prompt: string;
  posterUrl: string;
  duration: number;
  aspect: string;
  provider: string;
  createdAt: number;
};

const K = {
  gallery: "studio.gallery.v1",
  prompts: "studio.prompts.v2",
  refs: "studio.refs.v2",
  motion: "studio.motion.v1",
  lipsync: "studio.lipsync.v1",
  videos: "studio.videos.v1",
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error("studio-store write failed", err);
  }
}

function crud<T extends { id: string }>(key: string, cap = 200) {
  return {
    list: (): T[] => read<T[]>(key, []),
    add: (item: T) => write(key, [item, ...read<T[]>(key, [])].slice(0, cap)),
    update: (id: string, patch: Partial<T>) =>
      write(
        key,
        read<T[]>(key, []).map((x) => (x.id === id ? { ...x, ...patch } : x)),
      ),
    upsert: (item: T) =>
      write(key, [item, ...read<T[]>(key, []).filter((x) => x.id !== item.id)].slice(0, cap)),
    remove: (id: string) => write(key, read<T[]>(key, []).filter((x) => x.id !== id)),
    clear: () => write(key, []),
  };
}

export const gallery = {
  ...crud<GalleryItem>(K.gallery, 200),
};

export const refs = {
  ...crud<ReferenceItem>(K.refs, 100),
  selected: (): ReferenceItem[] => read<ReferenceItem[]>(K.refs, []).filter((r) => r.selected),
};

export const prompts = {
  list: (): PromptItem[] => read<PromptItem[]>(K.prompts, []),
  save: (item: PromptItem) => {
    const list = prompts.list();
    const existing = list.find((p) => p.id === item.id);
    const versions = existing?.versions ?? [];
    const bodyChanged = existing && existing.body !== item.body;
    const nextVersions: PromptVersion[] = bodyChanged
      ? [
          {
            id: uid(),
            body: existing!.body,
            title: existing!.title,
            createdAt: existing!.updatedAt ?? existing!.createdAt,
          },
          ...versions,
        ].slice(0, 20)
      : versions;
    const next: PromptItem = {
      ...item,
      updatedAt: Date.now(),
      versions: nextVersions,
    };
    write(K.prompts, [next, ...list.filter((p) => p.id !== item.id)]);
  },
  remove: (id: string) => write(K.prompts, prompts.list().filter((p) => p.id !== id)),
  import: (items: PromptItem[]) => write(K.prompts, [...items, ...prompts.list()]),
  restore: (id: string, versionId: string) => {
    const list = prompts.list();
    const p = list.find((x) => x.id === id);
    const v = p?.versions?.find((x) => x.id === versionId);
    if (!p || !v) return;
    prompts.save({ ...p, title: v.title, body: v.body });
  },
};

export const motion = crud<MotionClip>(K.motion, 60);
export const lipsync = crud<LipSyncJob>(K.lipsync, 60);
export const videos = crud<VideoClip>(K.videos, 60);

export const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export const fileToDataUrl = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
