import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Clapperboard, Plus, Trash2, Wand2, Film, Loader2, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { streamImage } from "@/lib/streamImage";
import { uid } from "@/lib/studio-store";

export const Route = createFileRoute("/storyboard")({
  head: () => ({
    meta: [
      { title: "Storyboard — AI Studio" },
      { name: "description", content: "Plan scenes, generate frames, compile to full video." },
      { property: "og:title", content: "Storyboard — AI Studio" },
      { property: "og:description", content: "Scene-by-scene storyboard to video pipeline." },
    ],
  }),
  component: Storyboard,
});

type Variant = {
  id: string;
  url: string | null;
  status: "idle" | "loading" | "done" | "error";
};

type Scene = {
  id: string;
  title: string;
  prompt: string;
  duration: number;
  variants: Variant[];
  selectedVariantId: string | null;
};

const mkVariants = (n: number): Variant[] =>
  Array.from({ length: n }, () => ({ id: uid(), url: null, status: "idle" as const }));

const starter: Scene[] = [
  {
    id: uid(),
    title: "Opening",
    prompt: "Wide establishing shot at dawn, mist over mountains, cinematic",
    duration: 4,
    variants: mkVariants(1),
    selectedVariantId: null,
  },
  {
    id: uid(),
    title: "Reveal",
    prompt: "Slow push toward a lone figure standing at a cliff edge",
    duration: 5,
    variants: mkVariants(1),
    selectedVariantId: null,
  },
  {
    id: uid(),
    title: "Close",
    prompt: "Close-up on face, wind in hair, golden hour rim light",
    duration: 3,
    variants: mkVariants(1),
    selectedVariantId: null,
  },
];

function Storyboard() {
  const [scenes, setScenes] = useState<Scene[]>(starter);
  const [style, setStyle] = useState("Cinematic anamorphic, 35mm film grain, muted teal-orange");
  const [batchCount, setBatchCount] = useState(2);
  const [compiling, setCompiling] = useState(false);

  const update = (id: string, patch: Partial<Scene>) =>
    setScenes((s) => s.map((sc) => (sc.id === id ? { ...sc, ...patch } : sc)));

  const patchVariant = (sceneId: string, variantId: string, patch: Partial<Variant>) =>
    setScenes((s) =>
      s.map((sc) =>
        sc.id === sceneId
          ? {
              ...sc,
              variants: sc.variants.map((v) => (v.id === variantId ? { ...v, ...patch } : v)),
            }
          : sc,
      ),
    );

  const add = () =>
    setScenes((s) => [
      ...s,
      {
        id: uid(),
        title: `Scene ${s.length + 1}`,
        prompt: "",
        duration: 4,
        variants: mkVariants(batchCount),
        selectedVariantId: null,
      },
    ]);

  const remove = (id: string) => setScenes((s) => s.filter((sc) => sc.id !== id));

  const move = (id: string, dir: -1 | 1) => {
    setScenes((s) => {
      const i = s.findIndex((sc) => sc.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= s.length) return s;
      const copy = [...s];
      [copy[i], copy[j]] = [copy[j], copy[i]];
      return copy;
    });
  };

  const selectedFrame = (sc: Scene): string | null => {
    const v =
      sc.variants.find((x) => x.id === sc.selectedVariantId) ??
      sc.variants.find((x) => x.status === "done");
    return v?.url ?? null;
  };

  async function generateVariant(sceneId: string, variantId: string, prompt: string, seed: number) {
    patchVariant(sceneId, variantId, { status: "loading", url: null });
    try {
      await streamImage(
        "/api/generate-image",
        `${prompt}. Style: ${style}. Storyboard frame. Variation seed ${seed}.`,
        (url, final) => {
          patchVariant(sceneId, variantId, { url, status: final ? "done" : "loading" });
        },
      );
    } catch (e) {
      patchVariant(sceneId, variantId, { status: "error" });
      toast.error((e as Error).message);
    }
  }

  async function generateScene(sc: Scene) {
    if (!sc.prompt.trim()) return toast.error("Add a prompt to this scene");
    // Ensure the scene has `batchCount` variants (reset them for a fresh batch).
    const fresh = mkVariants(batchCount);
    update(sc.id, { variants: fresh, selectedVariantId: null });
    // Fire variants in parallel — each is a distinct output node.
    await Promise.all(
      fresh.map((v, i) => generateVariant(sc.id, v.id, sc.prompt, Date.now() + i * 7)),
    );
  }

  async function generateAll() {
    for (const sc of scenes) {
      await generateScene(sc);
    }
  }

  async function compile() {
    const missing = scenes.filter((s) => !selectedFrame(s));
    if (missing.length) return toast.error(`${missing.length} scene(s) missing a chosen frame`);
    setCompiling(true);
    const total = scenes.reduce((a, s) => a + s.duration, 0);
    setTimeout(() => {
      setCompiling(false);
      toast.success(
        `Storyboard queued for compilation · ${scenes.length} scenes · ${total}s. Connect a video provider (Kling, Veo, Luma) to render MP4.`,
      );
    }, 900);
  }

  const totalDur = scenes.reduce((a, s) => a + s.duration, 0);

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
            <Clapperboard className="h-3.5 w-3.5" /> Storyboard → Video
          </div>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight">Storyboard</h1>
          <p className="mt-2 text-sm text-muted-foreground max-w-xl">
            Plan scenes, batch-generate variant frames per output node, pick the best, then compile.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={generateAll}>
            <Wand2 className="h-4 w-4" /> Batch generate all
          </Button>
          <Button onClick={compile} disabled={compiling} className="glow">
            {compiling ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Film className="h-4 w-4" />
            )}
            Compile to video
          </Button>
        </div>
      </div>

      <div className="mt-6 glass rounded-2xl p-4 flex items-center gap-3 flex-wrap">
        <div className="text-xs uppercase tracking-widest text-muted-foreground">Global style</div>
        <Input
          value={style}
          onChange={(e) => setStyle(e.target.value)}
          className="flex-1 min-w-[240px] glass"
        />
        <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
          Batch
          <Input
            type="number"
            min={1}
            max={6}
            value={batchCount}
            onChange={(e) => setBatchCount(Math.max(1, Math.min(6, Number(e.target.value) || 1)))}
            className="w-16 glass"
          />
          <span className="normal-case tracking-normal">variants / scene</span>
        </div>
        <div className="text-xs text-muted-foreground tabular-nums">
          {scenes.length} scenes · {totalDur}s total
        </div>
      </div>

      <div className="mt-6 space-y-4">
        {scenes.map((sc, idx) => {
          const anyLoading = sc.variants.some((v) => v.status === "loading");
          return (
            <div key={sc.id} className="glass rounded-2xl p-4 space-y-4">
              <div className="grid gap-4 md:grid-cols-[1fr_auto]">
                <div className="space-y-2 min-w-0">
                  <div className="flex gap-2 items-center">
                    <div className="text-[10px] px-1.5 py-0.5 rounded bg-background/70 backdrop-blur">
                      #{idx + 1}
                    </div>
                    <Input
                      value={sc.title}
                      onChange={(e) => update(sc.id, { title: e.target.value })}
                      className="glass font-medium"
                    />
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Input
                        type="number"
                        min={1}
                        max={20}
                        value={sc.duration}
                        onChange={(e) => update(sc.id, { duration: Number(e.target.value) || 1 })}
                        className="w-16 glass"
                      />
                      <span>sec</span>
                    </div>
                  </div>
                  <Textarea
                    value={sc.prompt}
                    onChange={(e) => update(sc.id, { prompt: e.target.value })}
                    placeholder="Describe the shot…"
                    className="h-20 resize-none glass"
                  />
                </div>

                <div className="flex md:flex-col gap-2 justify-end">
                  <Button size="sm" onClick={() => generateScene(sc)} disabled={anyLoading}>
                    {anyLoading ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Wand2 className="h-3.5 w-3.5" />
                    )}
                    Batch × {batchCount}
                  </Button>
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary" onClick={() => move(sc.id, -1)}>
                      <GripVertical className="h-3.5 w-3.5 rotate-90" />
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => move(sc.id, 1)}>
                      <GripVertical className="h-3.5 w-3.5 -rotate-90" />
                    </Button>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => remove(sc.id)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>

              <div
                className="grid gap-2"
                style={{
                  gridTemplateColumns: `repeat(${sc.variants.length}, minmax(0, 1fr))`,
                }}
              >
                {sc.variants.map((v, vIdx) => {
                  const selected = sc.selectedVariantId === v.id;
                  return (
                    <button
                      type="button"
                      key={v.id}
                      onClick={() =>
                        v.url && update(sc.id, { selectedVariantId: selected ? null : v.id })
                      }
                      className={
                        "group aspect-video rounded-xl overflow-hidden bg-background/40 border relative text-left transition " +
                        (selected
                          ? "border-primary ring-2 ring-primary/60"
                          : "border-border/60 hover:border-border")
                      }
                    >
                      {v.url ? (
                        <img
                          src={v.url}
                          className={
                            "h-full w-full object-cover transition-[filter] duration-500 " +
                            (v.status === "done" ? "blur-0" : "blur-xl")
                          }
                          alt=""
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center text-xs text-muted-foreground">
                          {v.status === "loading" ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : v.status === "error" ? (
                            "Error"
                          ) : (
                            "Empty"
                          )}
                        </div>
                      )}
                      <div className="absolute top-1.5 left-1.5 text-[10px] px-1.5 py-0.5 rounded bg-background/70 backdrop-blur">
                        Node {vIdx + 1}
                      </div>
                      {selected && (
                        <div className="absolute top-1.5 right-1.5 text-[10px] px-1.5 py-0.5 rounded bg-primary text-primary-foreground">
                          Selected
                        </div>
                      )}
                      <div
                        className="absolute bottom-1.5 right-1.5 opacity-0 group-hover:opacity-100 transition"
                        onClick={(e) => {
                          e.stopPropagation();
                          generateVariant(sc.id, v.id, sc.prompt, Date.now() + vIdx * 13);
                        }}
                      >
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-background/80 backdrop-blur border border-border/60">
                          Regen
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}

        <Button variant="secondary" onClick={add} className="w-full">
          <Plus className="h-4 w-4" /> Add scene
        </Button>
      </div>
    </div>
  );
}

