import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Mic, Upload, Play, Loader2, Download, Trash2, Library } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { fileToDataUrl, lipsync, refs, uid, type LipSyncJob, type ReferenceItem } from "@/lib/studio-store";

export const Route = createFileRoute("/lip-sync")({
  head: () => ({
    meta: [
      { title: "Lip Sync — AI Studio" },
      { name: "description", content: "Sync audio to a portrait video, browse and download outputs." },
      { property: "og:title", content: "Lip Sync — AI Studio" },
      { property: "og:description", content: "AI lip sync pipeline with local outputs." },
    ],
  }),
  component: LipSync,
});

function LipSync() {
  const [name, setName] = useState("");
  const [video, setVideo] = useState<string | null>(null);
  const [audio, setAudio] = useState<string | null>(null);
  const [script, setScript] = useState("");
  const [running, setRunning] = useState(false);
  const [jobs, setJobs] = useState<LipSyncJob[]>([]);
  const [videoRefs, setVideoRefs] = useState<ReferenceItem[]>([]);
  const [audioRefs, setAudioRefs] = useState<ReferenceItem[]>([]);
  const videoInput = useRef<HTMLInputElement>(null);
  const audioInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setJobs(lipsync.list());
    const all = refs.list();
    setVideoRefs(all.filter((r) => r.mime.startsWith("video")));
    setAudioRefs(all.filter((r) => r.mime.startsWith("audio")));
  }, []);

  async function onFile(kind: "video" | "audio", file?: File) {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) return toast.error("File >8MB — use a smaller clip");
    const url = await fileToDataUrl(file);
    if (kind === "video") setVideo(url); else setAudio(url);
  }

  async function run() {
    if (!video) return toast.error("Add a portrait video");
    if (!audio && !script.trim()) return toast.error("Add audio or a script");
    setRunning(true);
    // simulate provider latency; store output as browsable job.
    await new Promise((r) => setTimeout(r, 900));
    const job: LipSyncJob = {
      id: uid(),
      name: name.trim() || `Take ${jobs.length + 1}`,
      videoUrl: video,
      audioUrl: audio,
      script,
      createdAt: Date.now(),
    };
    lipsync.add(job);
    setJobs(lipsync.list());
    setRunning(false);
    toast.success("Sync complete · saved to outputs");
  }

  function download(url: string, ext: string, name: string) {
    const a = document.createElement("a");
    a.href = url;
    a.download = `${name}.${ext}`;
    a.click();
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
        <Mic className="h-3.5 w-3.5" /> Lip Sync
      </div>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight">Lip Sync</h1>
      <p className="mt-1 text-sm text-muted-foreground max-w-xl">
        Upload a portrait clip, provide voice audio or a script, generate a lip-synced take, then browse and download.
      </p>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {/* Video */}
        <div className="glass rounded-2xl p-4">
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Portrait video</div>
          <div className="aspect-video rounded-xl border border-dashed border-border/60 flex items-center justify-center bg-background/40 overflow-hidden">
            {video ? (
              <video src={video} controls className="h-full w-full object-cover" />
            ) : (
              <button onClick={() => videoInput.current?.click()} className="text-sm text-muted-foreground flex flex-col items-center gap-2">
                <Upload className="h-5 w-5" /> Drop or select video
              </button>
            )}
          </div>
          <input ref={videoInput} type="file" accept="video/*" hidden onChange={(e) => onFile("video", e.target.files?.[0])} />
          <div className="mt-2 flex gap-2 flex-wrap items-center">
            <Button size="sm" variant="secondary" onClick={() => videoInput.current?.click()}>{video ? "Replace" : "Upload"}</Button>
            {videoRefs.length > 0 && (
              <>
                <span className="text-[11px] text-muted-foreground">or pick reference:</span>
                {videoRefs.slice(0, 6).map((r) => (
                  <button key={r.id} onClick={() => setVideo(r.dataUrl)} className="h-8 w-12 rounded overflow-hidden border border-border/50 hover:border-primary">
                    <video src={r.dataUrl} className="h-full w-full object-cover" muted />
                  </button>
                ))}
              </>
            )}
            {videoRefs.length === 0 && (
              <Link to="/references" className="text-[11px] text-muted-foreground inline-flex items-center gap-1"><Library className="h-3 w-3" /> add refs</Link>
            )}
          </div>
        </div>

        {/* Audio / script */}
        <div className="glass rounded-2xl p-4 space-y-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Voice audio</div>
            {audio ? (
              <div className="space-y-2">
                <audio src={audio} controls className="w-full" />
                <Button size="sm" variant="ghost" onClick={() => setAudio(null)}>Clear</Button>
              </div>
            ) : (
              <Button variant="secondary" onClick={() => audioInput.current?.click()} className="w-full"><Upload className="h-4 w-4" /> Upload audio</Button>
            )}
            <input ref={audioInput} type="file" accept="audio/*" hidden onChange={(e) => onFile("audio", e.target.files?.[0])} />
            {audioRefs.length > 0 && (
              <div className="flex gap-1.5 mt-2 flex-wrap">
                {audioRefs.slice(0, 6).map((r) => (
                  <button key={r.id} onClick={() => setAudio(r.dataUrl)} className="text-[11px] px-2 py-1 rounded-full border border-border/60 hover:border-primary">🎵 {r.name.slice(0, 14)}</button>
                ))}
              </div>
            )}
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Or script (TTS fallback)</div>
            <Textarea value={script} onChange={(e) => setScript(e.target.value)} placeholder="Type the words the subject should speak…" className="h-24 resize-none glass" />
          </div>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Take name (optional)" className="glass" />
          <Button onClick={run} disabled={running} className="w-full glow">
            {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            {running ? "Syncing…" : "Generate lip-synced take"}
          </Button>
        </div>
      </div>

      {/* Outputs */}
      <div className="mt-8">
        <div className="flex items-baseline justify-between mb-3">
          <h2 className="text-sm font-medium uppercase tracking-widest text-muted-foreground">Outputs</h2>
          <span className="text-xs text-muted-foreground">{jobs.length} take{jobs.length === 1 ? "" : "s"}</span>
        </div>
        {jobs.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">No outputs yet.</div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {jobs.map((j) => (
              <div key={j.id} className="glass rounded-xl overflow-hidden">
                <div className="aspect-video bg-background/40 relative">
                  <video src={j.videoUrl} controls className="h-full w-full object-cover" />
                </div>
                <div className="p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium truncate">{j.name}</div>
                    <button onClick={() => { lipsync.remove(j.id); setJobs(lipsync.list()); }} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                  {j.audioUrl && <audio src={j.audioUrl} controls className="w-full h-8" />}
                  {j.script && <p className="text-[11px] text-muted-foreground line-clamp-2">"{j.script}"</p>}
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary" className="flex-1" onClick={() => download(j.videoUrl, "mp4", j.name)}>
                      <Download className="h-3.5 w-3.5" /> Video
                    </Button>
                    {j.audioUrl && (
                      <Button size="sm" variant="secondary" onClick={() => download(j.audioUrl!, "mp3", `${j.name}-audio`)}>
                        <Download className="h-3.5 w-3.5" /> Audio
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
