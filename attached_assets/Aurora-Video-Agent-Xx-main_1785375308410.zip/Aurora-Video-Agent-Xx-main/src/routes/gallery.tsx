import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Download, Trash2, Images, Film, Clock, Play, Zap, Edit3 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { gallery, type GalleryItem } from "@/lib/studio-store";
import { agentStore, styleLabels, type VideoProject } from "@/lib/agent-store";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Aurora Agent" },
      { name: "description", content: "All your generated videos and images." },
      { property: "og:title", content: "Gallery — Aurora Agent" },
      { property: "og:description", content: "Your video and image creation history." },
    ],
  }),
  component: Gallery,
});

type Tab = "videos" | "images";

function StatusBadge({ status }: { status: VideoProject["status"] }) {
  const map: Record<VideoProject["status"], { label: string; cls: string }> = {
    creating: { label: "Creating", cls: "bg-muted/70 text-muted-foreground" },
    scripting: { label: "Scripting", cls: "bg-yellow-500/20 text-yellow-400" },
    visuals: { label: "Visuals", cls: "bg-blue-500/20 text-blue-400" },
    voiceover: { label: "Voice", cls: "bg-purple-500/20 text-purple-400" },
    compiling: { label: "Compiling", cls: "bg-orange-500/20 text-orange-400" },
    editing: { label: "Ready", cls: "bg-primary/20 text-primary" },
    exported: { label: "Exported", cls: "bg-green-500/20 text-green-400" },
    failed: { label: "Failed", cls: "bg-destructive/20 text-destructive" },
  };
  const { label, cls } = map[status] ?? { label: status, cls: "" };
  return <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${cls}`}>{label}</span>;
}

function Gallery() {
  const [tab, setTab] = useState<Tab>("videos");
  const [images, setImages] = useState<GalleryItem[]>([]);
  const [videos, setVideos] = useState<VideoProject[]>([]);

  useEffect(() => {
    setImages(gallery.list());
    setVideos(agentStore.list());
  }, []);

  function removeImage(id: string) {
    gallery.remove(id);
    setImages(gallery.list());
  }

  function downloadImage(item: GalleryItem) {
    const a = document.createElement("a");
    a.href = item.dataUrl;
    a.download = `${item.id}.png`;
    a.click();
  }

  function removeVideo(id: string) {
    agentStore.remove(id);
    setVideos(agentStore.list());
    toast.success("Video project deleted");
  }

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      {/* Header */}
      <div className="flex items-end justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Gallery</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {videos.length} {videos.length === 1 ? "video" : "videos"} · {images.length}{" "}
            {images.length === 1 ? "image" : "images"}
          </p>
        </div>
        <Link to="/create">
          <Button className="glow gap-2">
            <Zap className="h-4 w-4" /> Create Video
          </Button>
        </Link>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 glass rounded-xl p-1 w-fit">
        <button
          onClick={() => setTab("videos")}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition ${
            tab === "videos"
              ? "bg-primary/15 text-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Film className="h-4 w-4" /> Videos
          <span className="text-[10px] bg-muted/60 px-1.5 py-0.5 rounded-full">
            {videos.length}
          </span>
        </button>
        <button
          onClick={() => setTab("images")}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition ${
            tab === "images"
              ? "bg-primary/15 text-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Images className="h-4 w-4" /> Images
          <span className="text-[10px] bg-muted/60 px-1.5 py-0.5 rounded-full">
            {images.length}
          </span>
        </button>
      </div>

      {/* Videos tab */}
      {tab === "videos" && (
        <>
          {videos.length === 0 ? (
            <div className="glass rounded-2xl p-16 text-center">
              <Film className="mx-auto h-10 w-10 text-muted-foreground opacity-40" />
              <div className="mt-4 text-lg font-medium">No videos yet</div>
              <div className="text-sm text-muted-foreground mt-1">
                Create your first video with Aurora Agent.
              </div>
              <Link to="/create" className="mt-6 inline-block">
                <Button className="glow gap-2">
                  <Zap className="h-4 w-4" /> Create Video
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {videos.map((v) => (
                <div
                  key={v.id}
                  className="group glass rounded-xl overflow-hidden border border-border/50 hover:border-primary/30 transition"
                >
                  {/* Thumbnail */}
                  <div className="aspect-video bg-muted/30 relative overflow-hidden">
                    {v.thumbnailUrl ? (
                      <img
                        src={v.thumbnailUrl}
                        alt={v.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center">
                        <Film className="h-8 w-8 text-muted-foreground/40" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-background/70 backdrop-blur">
                        <Play className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="absolute top-2 right-2">
                      <StatusBadge status={v.status} />
                    </div>
                    <div className="absolute top-2 left-2 text-[10px] px-1.5 py-0.5 rounded bg-background/70 backdrop-blur">
                      {styleLabels[v.style]}
                    </div>
                  </div>

                  <div className="p-3">
                    <div className="text-sm font-medium line-clamp-1">{v.title}</div>
                    <div className="mt-1 text-xs text-muted-foreground line-clamp-2">
                      {v.prompt}
                    </div>
                    <div className="mt-2 flex items-center gap-2 text-[11px] text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {new Date(v.createdAt).toLocaleDateString()}
                      <span>·</span>
                      <span>{v.scenes.length} scenes</span>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Link to="/editor" search={{ id: v.id }} className="flex-1">
                        <Button size="sm" variant="secondary" className="w-full gap-1.5">
                          <Edit3 className="h-3.5 w-3.5" /> Edit
                        </Button>
                      </Link>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-destructive"
                        onClick={() => {
                          if (confirm("Delete this video project?")) removeVideo(v.id);
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* Images tab */}
      {tab === "images" && (
        <>
          {images.length === 0 ? (
            <div className="glass rounded-2xl p-16 text-center">
              <Images className="mx-auto h-10 w-10 text-muted-foreground" />
              <div className="mt-4 text-lg font-medium">Nothing here yet</div>
              <div className="text-sm text-muted-foreground mt-1">
                Generate an image in the Playground.
              </div>
            </div>
          ) : (
            <>
              <div className="flex justify-end mb-4">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    if (confirm("Clear the entire image gallery?")) {
                      gallery.clear();
                      setImages([]);
                      toast.success("Gallery cleared");
                    }
                  }}
                >
                  Clear all
                </Button>
              </div>
              <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                {images.map((item) => (
                  <div
                    key={item.id}
                    className="group glass rounded-xl overflow-hidden border border-border/50"
                  >
                    <div className="aspect-square overflow-hidden">
                      <img
                        src={item.dataUrl}
                        alt={item.prompt}
                        className="h-full w-full object-cover transition group-hover:scale-105"
                      />
                    </div>
                    <div className="p-3">
                      <div className="text-xs text-muted-foreground line-clamp-2 h-8">
                        {item.prompt}
                      </div>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-[10px] text-muted-foreground">
                          {new Date(item.createdAt).toLocaleDateString()}
                        </span>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" onClick={() => downloadImage(item)}>
                            <Download className="h-3.5 w-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => removeImage(item.id)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
