import { createFileRoute } from "@tanstack/react-router";

// System prompt that instructs the model to return a structured video script.
const SYSTEM_PROMPT = `You are a professional video scriptwriter and creative director.
Given a user's video topic and parameters, generate a complete video production plan.

Return ONLY valid JSON with this exact structure:
{
  "title": "short engaging title for the video",
  "scenes": [
    {
      "index": 0,
      "title": "scene name",
      "script": "exact voiceover text for this scene (2-4 sentences)",
      "description": "detailed cinematic visual description for this scene (what the camera sees, lighting, motion, composition)",
      "duration": 6
    }
  ]
}

Rules:
- Create 4-8 scenes depending on target duration
- Each scene's voiceover should read naturally in its duration
- Visual descriptions must be specific, cinematic, and detailed
- Total scene durations should add up to approximately the target duration
- Match the visual style to the requested style parameter
- Make the content professional, engaging, and high-quality
- Return ONLY the JSON object, no markdown, no explanation`;

// Model priority: Claude Fable → Claude Sonnet → Gemini Flash
// Identifiers follow the Lovable AI Gateway routing conventions.
const MODEL_PRIORITY = [
  "anthropic/claude-opus-4-5", // Claude Fable (best quality)
  "anthropic/claude-sonnet-4-5", // Claude Sonnet (fast + capable)
  "google/gemini-2.5-flash", // Gemini Flash (fallback)
];

export const Route = createFileRoute("/api/agent/generate-script")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as {
          prompt: string;
          style: string;
          voice: string;
          targetDuration: number;
        };

        const { prompt, style, targetDuration } = body;

        if (!prompt || typeof prompt !== "string") {
          return new Response("Missing prompt", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const userMessage = `Video topic: ${prompt}
Visual style: ${style}
Target duration: ${targetDuration} seconds
Number of scenes: ${Math.max(4, Math.round(targetDuration / 15))}

Generate a complete professional video script with cinematic scene descriptions.`;

        // Try models in priority order; move to next on failure.
        let lastError = "";
        for (const model of MODEL_PRIORITY) {
          let upstream: Response;
          try {
            upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
              method: "POST",
              headers: {
                Authorization: "Bearer " + key,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                model,
                messages: [
                  { role: "system", content: SYSTEM_PROMPT },
                  { role: "user", content: userMessage },
                ],
                temperature: 0.8,
                max_tokens: 4096,
              }),
            });
          } catch (fetchErr) {
            lastError = `${model}: network error — ${(fetchErr as Error).message}`;
            continue;
          }

          if (!upstream.ok) {
            const errText = await upstream.text().catch(() => "Unknown error");
            // 4xx client errors (bad request, auth) should not be retried
            if (upstream.status >= 400 && upstream.status < 500) {
              return new Response(errText, { status: upstream.status });
            }
            lastError = `${model}: ${upstream.status} ${errText}`;
            continue;
          }

          const data = (await upstream.json()) as {
            choices?: Array<{ message?: { content?: string } }>;
          };

          const content = data?.choices?.[0]?.message?.content ?? "";

          // Strip markdown code fences if present
          const cleaned = content
            .replace(/^```json\s*/i, "")
            .replace(/^```\s*/i, "")
            .replace(/\s*```$/i, "")
            .trim();

          // Validate JSON before returning
          try {
            JSON.parse(cleaned);
          } catch {
            lastError = `${model}: returned invalid JSON`;
            continue;
          }

          return new Response(cleaned, {
            headers: { "Content-Type": "application/json" },
          });
        }

        // All models exhausted
        return new Response(JSON.stringify({ error: "All models failed", detail: lastError }), {
          status: 502,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
