import { createFileRoute } from "@tanstack/react-router";
import { Bot, Check, Plug } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/providers")({
  head: () => ({
    meta: [
      { title: "AI Providers — AI Studio" },
      { name: "description", content: "Connect and manage AI provider adapters." },
      { property: "og:title", content: "AI Providers — AI Studio" },
      { property: "og:description", content: "Manage AI provider integrations." },
    ],
  }),
  component: Providers,
});

const providers = [
  { name: "Lovable AI Gateway", desc: "Chat, image, embeddings — zero setup.", connected: true },
  { name: "OpenAI", desc: "GPT models via Gateway.", connected: true },
  { name: "Anthropic Claude", desc: "Claude family via Gateway.", connected: true },
  { name: "Google Gemini", desc: "Gemini + Nano Banana image models.", connected: true },
  { name: "Fal.ai", desc: "Fast diffusion + video.", connected: false },
  { name: "HuggingFace", desc: "Inference endpoints.", connected: false },
  { name: "Replicate", desc: "Community models.", connected: false },
  { name: "Runware", desc: "Realtime image gen.", connected: false },
  { name: "Kling", desc: "Video + motion control.", connected: false },
  { name: "Seedance", desc: "Cinematic video.", connected: false },
  { name: "Minimax", desc: "Video + lip sync.", connected: false },
  { name: "Google Veo", desc: "Long-form video.", connected: false },
  { name: "Luma", desc: "Dream Machine video.", connected: false },
];

function Providers() {
  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
        <Bot className="h-3.5 w-3.5" /> Integrations
      </div>
      <h1 className="mt-3 text-4xl font-semibold tracking-tight">AI Providers</h1>
      <p className="mt-2 text-muted-foreground max-w-xl">
        Connect adapters to unlock models across chat, image, video, and audio. Lovable AI Gateway
        ships pre-wired; add API keys to enable the rest.
      </p>

      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {providers.map((p) => (
          <div key={p.name} className="glass rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div className="font-medium">{p.name}</div>
              {p.connected ? (
                <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-primary">
                  <Check className="h-3 w-3" /> Live
                </span>
              ) : (
                <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                  Adapter
                </span>
              )}
            </div>
            <div className="mt-1 text-xs text-muted-foreground">{p.desc}</div>
            <Button
              size="sm"
              variant={p.connected ? "secondary" : "default"}
              className="mt-3 w-full"
              disabled={p.connected}
            >
              <Plug className="h-3.5 w-3.5" />
              {p.connected ? "Connected" : "Connect"}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
