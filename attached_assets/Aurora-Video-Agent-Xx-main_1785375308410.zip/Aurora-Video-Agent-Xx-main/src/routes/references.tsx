import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { UploadCloud, Trash2, Library, Search, Check, Tag, X, Wand2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { refs, uid, fileToDataUrl, type ReferenceItem } from "@/lib/studio-store";

export const Route = createFileRoute("/references")({
  head: () => ({
    meta: [
      { title: "References — AI Studio" },
      { name: "description", content: "Upload, tag, and select references for generation." },
      { property: "og:title", content: "References — AI Studio" },
      { property: "og:description", content: "Reference library for AI generation." },
    ],
  }),
  component: References,
});

const ACCEPT = "image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm,video/quicktime";

function References() {
  const [items, setItems] = useState<ReferenceItem[]>([]);
  const [q, setQ] = useState("");
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [tagDraft, setTagDraft] = useState<Record<string, string>>({});
  const inputRef = useRef<HTMLInputElement>(null);

  const refresh = () => setItems(refs.list());
  useEffect(refresh, []);

  async function handleFiles(files: FileList | null) {
    if (!files) return;
    let added = 0;
    for (const f of Array.from(files)) {
      if (f.size > 5 * 1024 * 1024) {
        toast.error(`${f.name} >5MB — skipped`);
        continue;
      }
      try {
        const dataUrl = await fileToDataUrl(f);
        refs.add({
          id: uid(),
          name: f.name,
          dataUrl,
          mime: f.type,
          tags: [],
          selected: false,
          createdAt: Date.now(),
        });
        added++;
      } catch {
        toast.error(`Failed to read ${f.name}`);
      }
    }
    refresh();
    if (added) toast.success(`${added} added`);
  }

  function addTag(id: string) {
    const raw = (tagDraft[id] ?? "").trim();
    if (!raw) return;
    const item = items.find((r) => r.id === id);
    if (!item) return;
    const tags = Array.from(new Set([...item.tags, ...raw.split(",").map((t) => t.trim()).filter(Boolean)]));
    refs.update(id, { tags });
    setTagDraft((d) => ({ ...d, [id]: "" }));
    refresh();
  }

  function removeTag(id: string, tag: string) {
    const item = items.find((r) => r.id === id);
    if (!item) return;
    refs.update(id, { tags: item.tags.filter((t) => t !== tag) });
    refresh();
  }

  function toggleSelect(id: string) {
    const item = items.find((r) => r.id === id);
    if (!item) return;
    refs.update(id, { selected: !item.selected });
    refresh();
  }

  const allTags = Array.from(new Set(items.flatMap((r) => r.tags))).sort();
  const filtered = items.filter((r) => {
    if (activeTag && !r.tags.includes(activeTag)) return false;
    if (!q.trim()) return true;
    const s = q.toLowerCase();
    return r.name.toLowerCase().includes(s) || r.tags.some((t) => t.toLowerCase().includes(s));
  });
  const selectedCount = items.filter((r) => r.selected).length;

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      <header className="flex items-end justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">References</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {items.length} items · {selectedCount} selected for generation
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" className="pl-8 w-56 glass" />
          </div>
          <Button onClick={() => inputRef.current?.click()}>
            <UploadCloud className="h-4 w-4" /> Upload
          </Button>
          <input ref={inputRef} type="file" multiple accept={ACCEPT} hidden onChange={(e) => handleFiles(e.target.files)} />
        </div>
      </header>

      {selectedCount > 0 && (
        <div className="glass rounded-xl px-4 py-3 mb-4 flex items-center gap-3 flex-wrap">
          <span className="text-xs uppercase tracking-widest text-primary">
            {selectedCount} ref{selectedCount === 1 ? "" : "s"} active
          </span>
          <span className="text-xs text-muted-foreground">Used automatically by Playground, Motion &amp; Lip Sync</span>
          <div className="flex-1" />
          <Link to="/playground"><Button size="sm" variant="secondary"><Wand2 className="h-3.5 w-3.5" /> Playground</Button></Link>
          <Link to="/motion-control"><Button size="sm" variant="secondary">Motion</Button></Link>
          <Button size="sm" variant="ghost" onClick={() => { items.forEach((r) => r.selected && refs.update(r.id, { selected: false })); refresh(); }}>
            Clear
          </Button>
        </div>
      )}

      {allTags.length > 0 && (
        <div className="flex gap-1.5 mb-4 flex-wrap">
          <button onClick={() => setActiveTag(null)} className={"px-2.5 py-1 rounded-full text-[11px] border " + (activeTag === null ? "bg-primary/20 border-primary/50 text-primary" : "border-border/60 text-muted-foreground hover:border-primary/40")}>All</button>
          {allTags.map((t) => (
            <button key={t} onClick={() => setActiveTag(t === activeTag ? null : t)} className={"px-2.5 py-1 rounded-full text-[11px] border " + (activeTag === t ? "bg-primary/20 border-primary/50 text-primary" : "border-border/60 text-muted-foreground hover:border-primary/40")}>#{t}</button>
          ))}
        </div>
      )}

      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
        className={"glass rounded-2xl p-6 border-2 border-dashed transition " + (dragging ? "border-primary bg-primary/10" : "border-border/50")}
      >
        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <Library className="mx-auto h-10 w-10 text-muted-foreground" />
            <div className="mt-3 text-sm">{items.length === 0 ? "Drop files here or click Upload." : "No matches."}</div>
          </div>
        ) : (
          <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {filtered.map((r) => (
              <div key={r.id} className={"group relative rounded-lg overflow-hidden border transition " + (r.selected ? "border-primary ring-2 ring-primary/50" : "border-border/50 hover:border-border")}>
                <button onClick={() => toggleSelect(r.id)} className="block w-full aspect-square bg-background/40 relative">
                  {r.mime.startsWith("video") ? (
                    <video src={r.dataUrl} className="h-full w-full object-cover" muted />
                  ) : (
                    <img src={r.dataUrl} alt={r.name} className="h-full w-full object-cover" />
                  )}
                  {r.selected && (
                    <div className="absolute top-1.5 left-1.5 h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                      <Check className="h-3.5 w-3.5 text-primary-foreground" />
                    </div>
                  )}
                </button>
                <Button size="icon" variant="destructive" className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition" onClick={() => { refs.remove(r.id); refresh(); }}>
                  <Trash2 className="h-3 w-3" />
                </Button>
                <div className="p-2 space-y-1.5">
                  <div className="text-[11px] truncate" title={r.name}>{r.name}</div>
                  <div className="flex flex-wrap gap-1">
                    {r.tags.map((t) => (
                      <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary flex items-center gap-1">
                        #{t}
                        <button onClick={() => removeTag(r.id, t)}><X className="h-2.5 w-2.5" /></button>
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-1">
                    <Tag className="h-3 w-3 text-muted-foreground" />
                    <Input
                      value={tagDraft[r.id] ?? ""}
                      onChange={(e) => setTagDraft((d) => ({ ...d, [r.id]: e.target.value }))}
                      onKeyDown={(e) => e.key === "Enter" && addTag(r.id)}
                      onBlur={() => addTag(r.id)}
                      placeholder="add tag…"
                      className="h-6 text-[11px] px-1.5 glass"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
