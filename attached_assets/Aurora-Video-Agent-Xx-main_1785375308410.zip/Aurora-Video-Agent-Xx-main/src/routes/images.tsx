import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/images")({
  head: () => ({
    meta: [
      { title: "Images — AI Studio" },
      { name: "description", content: "Generate images with streaming previews." },
      { property: "og:title", content: "Images — AI Studio" },
      { property: "og:description", content: "AI image generation workspace." },
    ],
  }),
  component: () => <Navigate to="/playground" replace />,
});
