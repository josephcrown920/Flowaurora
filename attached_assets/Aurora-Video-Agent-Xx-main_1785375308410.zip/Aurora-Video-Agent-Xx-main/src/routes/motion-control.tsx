import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Move3d, Play, Loader2, Plus, Trash2, Wand2, Save, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { streamImage } from "@/lib/streamImage";
import { motion, refs, uid, type MotionClip, type MotionKeyframe, type ReferenceItem } from "@/lib/studio-store";

export const Route = createFileRoute("/motion-control")({
  head: () => ({
    meta: [
      { title: "Motion Control — AI Studio" },
      { name: "description", content: "Timeline editor for AI motion generation." },
      { property: "og:title", content: "Motion Control — AI Studio" },
      { property: "og:description", content: "Keyframe timeline for motion-controlled AI clips." },
    ],
  }),
  component: MotionControl,
});

const cameras = ["Static", "Dolly in", "Dolly out", "Pan left", "Pan right", "Tilt up", "Tilt down", "Orbit", "Crane", "Handheld"];

const seed = (): MotionKeyframe[] => [
  { id: uid(), time: 0, prompt: "Wide shot, cinematic dawn light", status: "idle" },
  { id: uid(), time: 2, prompt: "Camera pushes toward the subject", status: "idle" },
  { id: uid(), time: 4, prompt: "Close-up, golden rim light", status: "idle" },
];

function MotionControl() {
  const [duration, setDuration] = useState(6);
  const [camera, setCamera] = useState("Dolly in");
  const [intensity, setIntensity] = useState([50]);
  const [keys, setKeys] = useState<MotionKeyframe[]>(seed());
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [playhead, setPlayhead] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [saved, setSaved] = useState<MotionClip[]>([]);
  const [selectedRefs, setSelectedRefs] = useState<ReferenceItem[]>([]);
  const rafRef = useRef<number | null>(null);
  const startRef = useRef(0);

  useEffect(() => {
    setSaved(motion.list());
    setSelectedRefs(refs.selected());
  }, []);

  useEffect(() => {
    if (!playing) return;
    startRef.current = performance.now() - playhead * 1000;
    const tick = () => {
      const t = (performance.now() - startRef.current) / 1000;
      if (t >= duration) { setPlayhead(duration); setPlaying(false); return; }
      setPlayhead(t);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  const selected = keys.find((k) => k.id === selectedId) ?? null;

  const updateKey = (id: string, patch: Partial<MotionKeyframe>) =>
    setKeys((ks) => ks.map((k) => (k.id === id ? { ...k, ...patch } : k)));

  const addKey = () => {
    const k: MotionKeyframe = { id: uid(), time: Number(playhead.toFixed(2)), prompt: "", status: "idle" };
    setKeys((ks) => [...ks, k].sort((a, b) => a.time - b.time));
    setSelectedId(k.id);
  };

  const removeKey = (id: string) => setKeys((ks) => ks.filter((k) => k.id !== id));

  async function generateOne(k: MotionKeyframe) {
    if (!k.prompt.trim()) return toast.error("Add a prompt");
    updateKey(k.id, { status: "loading", imageUrl: undefined });
    const refBits = selectedRefs.length ? ` Referenced from: ${selectedRefs.map((r) => r.name).join(", ")}.` : "";
    const prompt = `${k.prompt}. Camera: ${camera} at ${intensity[0]}% intensity.${refBits} Frame at ${k.time.toFixed(1)}s of ${duration}s clip.`;
    try {
      await streamImage("/api/generate-image", prompt, (url, final) => {
        updateKey(k.id, { imageUrl: url, status: final ? "done" : "loading" });
      });
    } catch (e) {
      updateKey(k.id, { status: "error" });
      toast.error((e as Error).message);
    }
  }

  async function generateAll() {
    for (const k of keys) await generateOne(k);
    toast.success("Motion frames ready");
  }

  function saveClip() {
    const clip: MotionClip = {
      id: uid(), name: `Clip ${saved.length + 1}`, duration, camera, intensity: intensity[0], keyframes: keys, createdAt: Date.now(),
    };
    motion.add(clip); setSaved(motion.list()); toast.success("Saved");
  }

  function loadClip(c: MotionClip) {
    setDuration(c.duration); setCamera(c.camera); setIntensity([c.intensity]); setKeys(c.keyframes); setPlayhead(0);
  }

  // interpolate between nearest keyframes for scrubber preview
  const preview = (() => {
    const sorted = [...keys].filter((k) => k.imageUrl).sort((a, b) => a.time - b.time);
    if (!sorted.length) return null;
    const prev = [...sorted].reverse().find((k) => k.time <= playhead) ?? sorted[0];
    return prev.imageUrl ?? null;
  })();

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
        <Move3d className="h-3.5 w-3.5" /> Motion Control
      </div>
      <div className="mt-2 flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Motion Control</h1>
          <p className="mt-1 text-sm text-muted-foreground">Timeline of keyframes → motion-controlled clip.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={generateAll}><Wand2 className="h-4 w-4" /> Generate all frames</Button>
          <Button onClick={saveClip} className="glow"><Save className="h-4 w-4" /> Save clip</Button>
        </div>
      </div>

      {selectedRefs.length > 0 && (
        <div className="mt-4 glass rounded-xl px-3 py-2 text-xs text-muted-foreground flex items-center gap-2">
          <span className="text-primary uppercase tracking-widest">{selectedRefs.length} ref{selectedRefs.length === 1 ? "" : "s"} active</span>
          <span className="truncate">{selectedRefs.map((r) => r.name).join(", ")}</span>
          <div className="flex-1" />
          <Link to="/references" className="underline">Manage</Link>
        </div>
      )}

      <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_360px]">
        {/* Preview */}
        <div className="glass rounded-2xl p-4">
          <div className="aspect-video rounded-xl overflow-hidden bg-background/40 border border-border/60 relative">
            {preview ? (
              <img src={preview} className="h-full w-full object-cover" alt="" />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-sm text-muted-foreground">
                <Move3d className="h-8 w-8 mr-2 text-primary/60" /> Generate frames to preview
              </div>
            )}
            <div className="absolute bottom-2 left-2 text-[10px] uppercase tracking-widest bg-background/70 backdrop-blur px-2 py-0.5 rounded">
              {camera} · {intensity[0]}% · {playhead.toFixed(1)}s / {duration}s
            </div>
          </div>

          {/* Timeline */}
          <div className="mt-4">
            <div className="flex items-center gap-2 mb-2">
              <Button size="icon" variant="secondary" onClick={() => setPlaying((p) => !p)}>
                {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button size="sm" variant="secondary" onClick={addKey}><Plus className="h-3.5 w-3.5" /> Key @ {playhead.toFixed(1)}s</Button>
              <div className="flex-1" />
              <span className="text-xs text-muted-foreground">Duration</span>
              <Input type="number" min={1} max={30} value={duration} onChange={(e) => setDuration(Math.max(1, Number(e.target.value) || 1))} className="w-16 h-8 glass" />
              <span className="text-xs text-muted-foreground">s</span>
            </div>
            <div className="relative h-16 rounded-lg glass overflow-hidden">
              <div className="absolute inset-0 flex">
                {Array.from({ length: duration + 1 }).map((_, i) => (
                  <div key={i} className="flex-1 border-l border-border/30 first:border-transparent text-[9px] text-muted-foreground px-1">{i}s</div>
                ))}
              </div>
              {keys.map((k) => {
                const left = (k.time / duration) * 100;
                const active = k.id === selectedId;
                return (
                  <button
                    key={k.id}
                    onClick={() => { setSelectedId(k.id); setPlayhead(k.time); }}
                    style={{ left: `${left}%` }}
                    className={"absolute top-2 -translate-x-1/2 h-12 w-6 rounded flex flex-col items-center justify-center border transition " + (active ? "bg-primary/40 border-primary" : "bg-primary/15 border-primary/40 hover:bg-primary/25")}
                    title={k.prompt}
                  >
                    {k.status === "loading" ? <Loader2 className="h-3 w-3 animate-spin" /> :
                     k.status === "done" ? <div className="h-2 w-2 rounded-full bg-primary" /> :
                     k.status === "error" ? <div className="h-2 w-2 rounded-full bg-destructive" /> :
                     <div className="h-2 w-2 rounded-full bg-muted-foreground/60" />}
                    <span className="text-[9px] tabular-nums mt-0.5">{k.time.toFixed(1)}</span>
                  </button>
                );
              })}
              <div className="absolute top-0 bottom-0 w-px bg-primary" style={{ left: `${(playhead / duration) * 100}%` }} />
            </div>
            <input type="range" min={0} max={duration} step={0.1} value={playhead} onChange={(e) => setPlayhead(Number(e.target.value))} className="w-full mt-2 accent-primary" />
          </div>
        </div>

        {/* Right panel: keyframe editor + camera */}
        <div className="space-y-4">
          <div className="glass rounded-2xl p-4 space-y-3">
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Camera</div>
            <div className="flex flex-wrap gap-1.5">
              {cameras.map((c) => (
                <button key={c} onClick={() => setCamera(c)} className={"px-2 py-1 rounded-full text-[11px] border " + (camera === c ? "border-primary/60 bg-primary/20 text-foreground" : "border-border/60 text-muted-foreground hover:border-primary/40")}>{c}</button>
              ))}
            </div>
            <div>
              <div className="flex justify-between text-xs text-muted-foreground mb-1"><span>Intensity</span><span className="tabular-nums">{intensity[0]}%</span></div>
              <Slider value={intensity} onValueChange={setIntensity} min={0} max={100} step={5} />
            </div>
          </div>

          <div className="glass rounded-2xl p-4 space-y-3">
            <div className="text-xs uppercase tracking-widest text-muted-foreground flex items-center justify-between">
              <span>Keyframe {selected ? `@ ${selected.time.toFixed(1)}s` : ""}</span>
              {selected && <button className="text-destructive" onClick={() => { removeKey(selected.id); setSelectedId(null); }}><Trash2 className="h-3.5 w-3.5" /></button>}
            </div>
            {selected ? (
              <>
                <Input type="number" min={0} max={duration} step={0.1} value={selected.time} onChange={(e) => updateKey(selected.id, { time: Number(e.target.value) })} className="glass" />
                <Textarea value={selected.prompt} onChange={(e) => updateKey(selected.id, { prompt: e.target.value })} placeholder="Prompt for this frame…" className="h-28 resize-none glass" />
                <Button className="w-full glow" onClick={() => generateOne(selected)} disabled={selected.status === "loading"}>
                  {selected.status === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} Generate frame
                </Button>
                {selected.imageUrl && <img src={selected.imageUrl} className="rounded-lg w-full" alt="" />}
              </>
            ) : (
              <div className="text-xs text-muted-foreground">Select a keyframe on the timeline, or add one at the playhead.</div>
            )}
          </div>
        </div>
      </div>

      {saved.length > 0 && (
        <div className="mt-8">
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Saved clips</div>
          <div className="grid gap-2 md:grid-cols-3">
            {saved.map((c) => (
              <div key={c.id} className="glass rounded-xl p-3">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">{c.name}</div>
                  <button onClick={() => { motion.remove(c.id); setSaved(motion.list()); }} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
                <div className="text-[11px] text-muted-foreground">{c.keyframes.length} keys · {c.duration}s · {c.camera}</div>
                <Button size="sm" variant="secondary" className="mt-2 w-full" onClick={() => loadClip(c)}>Load</Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
