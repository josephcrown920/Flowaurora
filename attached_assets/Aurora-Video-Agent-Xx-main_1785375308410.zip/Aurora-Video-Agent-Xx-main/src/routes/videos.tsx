import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Film, Play, Loader2, Wand2, Download, Trash2, StopCircle, Library } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { streamImage } from "@/lib/streamImage";
import { refs, uid, videos, type ReferenceItem, type VideoClip } from "@/lib/studio-store";

export const Route = createFileRoute("/videos")({
  head: () => ({
    meta: [
      { title: "Videos — AI Studio" },
      { name: "description", content: "End-to-end AI video generation with streaming previews." },
      { property: "og:title", content: "Videos — AI Studio" },
      { property: "og:description", content: "Prompt → streaming preview → saved clip." },
    ],
  }),
  component: Videos,
});

const providers = [
  { id: "lovable", label: "Lovable AI Gateway" },
  { id: "kling", label: "Kling" },
  { id: "veo", label: "Google Veo" },
  { id: "luma", label: "Luma Dream Machine" },
  { id: "seedance", label: "Seedance" },
  { id: "minimax", label: "Minimax" },
];

const aspects = ["16:9", "9:16", "1:1", "21:9"];

function Videos() {
  const [prompt, setPrompt] = useState("");
  const [provider, setProvider] = useState("lovable");
  const [duration, setDuration] = useState(6);
  const [aspect, setAspect] = useState("16:9");
  const [poster, setPoster] = useState<string | null>(null);
  const [isFinal, setIsFinal] = useState(false);
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [clips, setClips] = useState<VideoClip[]>([]);
  const [selectedRefs, setSelectedRefs] = useState<ReferenceItem[]>([]);
  const abortRef = useRef<AbortController | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    setClips(videos.list());
    setSelectedRefs(refs.selected());
  }, []);

  const log = (line: string) => setLogs((l) => [`${new Date().toLocaleTimeString()} · ${line}`, ...l].slice(0, 60));

  async function generate() {
    const p = prompt.trim();
    if (!p) return toast.error("Enter a prompt");
    setPoster(null); setIsFinal(false); setRunning(true); setElapsed(0);
    const start = Date.now();
    timerRef.current = setInterval(() => setElapsed(Date.now() - start), 100);
    log(`▶ ${provider} · ${duration}s · ${aspect}`);
    const controller = new AbortController();
    abortRef.current = controller;
    const refBits = selectedRefs.length ? ` Reference styles: ${selectedRefs.map((r) => r.name).join(", ")}.` : "";
    const composed = `Cinematic ${aspect} keyframe for a ${duration}s video. ${p}.${refBits} Motion suggestion, high fidelity, poster frame.`;
    try {
      await streamImage("/api/generate-image", composed, (url, final) => {
        setPoster(url);
        if (final) {
          setIsFinal(true);
          log("✔ Keyframe rendered");
          const clip: VideoClip = { id: uid(), prompt: p, posterUrl: url, duration, aspect, provider, createdAt: Date.now() };
          videos.add(clip);
          setClips(videos.list());
        } else log("… partial frame");
      }, controller.signal);
    } catch (err) {
      if ((err as Error).name !== "AbortError") { log(`✖ ${(err as Error).message}`); toast.error((err as Error).message); }
      else log("■ Stopped");
    } finally {
      setRunning(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }

  function stop() { abortRef.current?.abort(); }
  function download(url: string, name: string) {
    const a = document.createElement("a"); a.href = url; a.download = `${name}.png`; a.click();
  }

  const aspectClass = aspect === "9:16" ? "aspect-[9/16] max-h-[520px] mx-auto" : aspect === "1:1" ? "aspect-square" : aspect === "21:9" ? "aspect-[21/9]" : "aspect-video";

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
        <Film className="h-3.5 w-3.5" /> Videos
      </div>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight">Videos</h1>
      <p className="mt-1 text-sm text-muted-foreground">End-to-end pipeline · streams keyframe live, saves clip to your library.</p>

      <div className="mt-6 grid gap-4 lg:grid-cols-[360px_1fr]">
        {/* Controls */}
        <div className="glass rounded-2xl p-4 space-y-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Prompt</div>
            <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="A neon-lit street at night, rain reflections…" className="h-28 resize-none glass" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Duration</div>
              <Input type="number" min={2} max={30} value={duration} onChange={(e) => setDuration(Math.max(2, Number(e.target.value) || 6))} className="glass" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Aspect</div>
              <Select value={aspect} onValueChange={setAspect}>
                <SelectTrigger className="glass"><SelectValue /></SelectTrigger>
                <SelectContent>{aspects.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Provider</div>
            <Select value={provider} onValueChange={setProvider}>
              <SelectTrigger className="glass"><SelectValue /></SelectTrigger>
              <SelectContent>{providers.map((p) => <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          {selectedRefs.length > 0 ? (
            <div className="text-[11px] text-muted-foreground flex items-center gap-2 border border-primary/30 bg-primary/10 rounded-lg px-2 py-1.5">
              <span className="text-primary uppercase tracking-widest">{selectedRefs.length} ref{selectedRefs.length === 1 ? "" : "s"}</span>
              <span className="truncate">{selectedRefs.map((r) => r.name).join(", ")}</span>
            </div>
          ) : (
            <Link to="/references" className="text-[11px] text-muted-foreground inline-flex items-center gap-1"><Library className="h-3 w-3" /> attach references</Link>
          )}

          {!running ? (
            <Button onClick={generate} className="w-full glow"><Wand2 className="h-4 w-4" /> Generate</Button>
          ) : (
            <Button onClick={stop} variant="destructive" className="w-full"><StopCircle className="h-4 w-4" /> Stop</Button>
          )}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{running ? <span className="inline-flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Streaming</span> : "Idle"}</span>
            <span className="tabular-nums">{(elapsed / 1000).toFixed(1)}s</span>
          </div>
          {logs.length > 0 && (
            <div className="text-[10px] font-mono text-muted-foreground border-t border-border/40 pt-2 max-h-32 overflow-auto space-y-0.5">
              {logs.map((l, i) => <div key={i}>{l}</div>)}
            </div>
          )}
        </div>

        {/* Live preview */}
        <div className="glass rounded-2xl p-4">
          <div className={"rounded-xl overflow-hidden bg-background/40 border border-border/60 relative " + aspectClass}>
            {poster ? (
              <>
                <img src={poster} className={"h-full w-full object-cover transition-[filter] duration-500 " + (isFinal ? "blur-0 kenburns" : "blur-2xl")} alt="Video keyframe" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-background/60 backdrop-blur">
                    <Play className="h-7 w-7 text-primary" />
                  </div>
                </div>
                <div className="absolute bottom-2 left-2 text-[10px] uppercase tracking-widest bg-background/70 backdrop-blur px-2 py-0.5 rounded">
                  {provider} · {duration}s · {aspect}
                </div>
                {isFinal && poster && (
                  <Button size="sm" variant="secondary" className="absolute top-2 right-2" onClick={() => download(poster, `video-${Date.now()}`)}>
                    <Download className="h-4 w-4" /> Poster
                  </Button>
                )}
              </>
            ) : (
              <div className="h-full w-full flex items-center justify-center text-sm text-muted-foreground">
                <div className="text-center">
                  <Film className="mx-auto h-10 w-10 text-primary/60" />
                  <div className="mt-2">Live preview will stream here.</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Library */}
      <div className="mt-8">
        <div className="flex items-baseline justify-between mb-3">
          <h2 className="text-sm font-medium uppercase tracking-widest text-muted-foreground">Your clips</h2>
          <span className="text-xs text-muted-foreground">{clips.length}</span>
        </div>
        {clips.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">Generated clips appear here.</div>
        ) : (
          <div className="grid gap-3 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {clips.map((c) => (
              <div key={c.id} className="glass rounded-xl overflow-hidden group">
                <div className="aspect-video bg-background/40 relative">
                  <img src={c.posterUrl} className="h-full w-full object-cover" alt="" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition bg-background/40">
                    <Play className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <div className="p-2 space-y-1">
                  <div className="text-xs truncate" title={c.prompt}>{c.prompt}</div>
                  <div className="text-[10px] text-muted-foreground flex items-center justify-between">
                    <span>{c.provider} · {c.duration}s · {c.aspect}</span>
                    <div className="flex gap-1">
                      <button onClick={() => download(c.posterUrl, `clip-${c.id}`)} className="hover:text-primary"><Download className="h-3 w-3" /></button>
                      <button onClick={() => { videos.remove(c.id); setClips(videos.list()); }} className="hover:text-destructive"><Trash2 className="h-3 w-3" /></button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
