import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Wand2,
  Film,
  Mic,
  Layers,
  ArrowRight,
  Sparkles,
  Play,
  Zap,
  Clock,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { agentStore, type VideoProject } from "@/lib/agent-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aurora Video Agent — AI-Powered Video Creation" },
      {
        name: "description",
        content:
          "Turn any idea into a stunning video. Aurora's AI agent writes the script, generates visuals, records voice-over, and compiles your video automatically.",
      },
      { property: "og:title", content: "Aurora Video Agent" },
      {
        property: "og:description",
        content: "Prompt → Script → Visuals → Voice → Video. Fully automated.",
      },
    ],
  }),
  component: Dashboard,
});

const features = [
  {
    icon: Wand2,
    title: "Smart Script Generation",
    desc: "Gemini AI writes a professional multi-scene script from your single prompt.",
  },
  {
    icon: Layers,
    title: "Scene-to-Visuals",
    desc: "Each scene gets a cinematic keyframe — generated automatically, styled to match.",
  },
  {
    icon: Mic,
    title: "Voice-Over Synthesis",
    desc: "Natural AI narration synced perfectly to each scene's timing.",
  },
  {
    icon: Film,
    title: "Multi-Provider Compilation",
    desc: "Export via Kling, Luma, Google Veo, or HeyGen — auto-selected for best results.",
  },
];

const steps = [
  { num: "01", label: "Enter your prompt" },
  { num: "02", label: "AI writes the script" },
  { num: "03", label: "Scenes are visualized" },
  { num: "04", label: "Voice is recorded" },
  { num: "05", label: "Video is compiled" },
];

function Dashboard() {
  const [recentProjects, setRecentProjects] = useState<VideoProject[]>([]);

  useEffect(() => {
    setRecentProjects(agentStore.list().slice(0, 4));
  }, []);

  return (
    <div className="min-h-screen">
      {/* ── Hero ── */}
      <section className="relative px-6 pt-20 pb-16 text-center overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[600px] w-[600px] rounded-full bg-primary/10 blur-[120px]" />
        </div>

        <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary mb-6">
          <Sparkles className="h-3 w-3" />
          AI Video Agent · Powered by Gemini
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight max-w-4xl mx-auto leading-[1.1]">
          Turn any idea into a <span className="text-gradient">stunning video</span>
        </h1>

        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          One prompt. Aurora's AI agent writes your script, generates cinematic visuals, records the
          voice-over, and compiles your final video — automatically.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center flex-wrap">
          <Link to="/create">
            <Button size="lg" className="glow text-base px-8 h-12 gap-2">
              <Zap className="h-5 w-5" />
              Create Video
            </Button>
          </Link>
          <Link to="/storyboard">
            <Button size="lg" variant="secondary" className="text-base px-8 h-12 gap-2">
              <Layers className="h-5 w-5" />
              Storyboard · Batch
            </Button>
          </Link>
          <Link to="/workflows">
            <Button size="lg" variant="secondary" className="text-base px-8 h-12 gap-2">
              <Wand2 className="h-5 w-5" />
              Workflows
            </Button>
          </Link>
          <Link to="/gallery">
            <Button size="lg" variant="ghost" className="text-base px-8 h-12 gap-2">
              <Play className="h-5 w-5" />
              Gallery
            </Button>
          </Link>
        </div>
      </section>

      {/* ── Pipeline Steps ── */}
      <section className="px-6 py-12 max-w-6xl mx-auto">
        <div className="glass rounded-2xl p-6">
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-4 text-center">
            How it works
          </div>
          <div className="flex flex-wrap justify-center gap-2 items-center">
            {steps.map((s, i) => (
              <div key={s.num} className="flex items-center gap-2">
                <div className="flex items-center gap-2 glass rounded-xl px-3 py-2">
                  <span className="text-[10px] font-mono text-primary">{s.num}</span>
                  <span className="text-sm font-medium">{s.label}</span>
                </div>
                {i < steps.length - 1 && (
                  <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section className="px-6 py-8 max-w-6xl mx-auto">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="glass rounded-2xl p-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary/30 to-primary-glow/20 border border-primary/30 mb-4">
                <f.icon className="h-5 w-5 text-primary" />
              </div>
              <div className="font-medium text-sm">{f.title}</div>
              <div className="mt-1.5 text-xs text-muted-foreground leading-relaxed">{f.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Recent Projects ── */}
      {recentProjects.length > 0 && (
        <section className="px-6 py-8 max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent projects</h2>
            <Link to="/gallery">
              <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground">
                View all <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {recentProjects.map((p) => (
              <Link key={p.id} to="/editor" search={{ id: p.id }}>
                <div className="group glass rounded-xl overflow-hidden border border-border/50 hover:border-primary/40 transition">
                  <div className="aspect-video bg-muted/30 relative">
                    {p.thumbnailUrl ? (
                      <img
                        src={p.thumbnailUrl}
                        alt={p.title}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center">
                        <Film className="h-8 w-8 text-muted-foreground/40" />
                      </div>
                    )}
                    <div className="absolute top-2 right-2">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                          p.status === "editing" || p.status === "exported"
                            ? "bg-primary/20 text-primary"
                            : "bg-muted/70 text-muted-foreground"
                        }`}
                      >
                        {p.status}
                      </span>
                    </div>
                  </div>
                  <div className="p-3">
                    <div className="text-sm font-medium line-clamp-1">{p.title}</div>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {new Date(p.createdAt).toLocaleDateString()}
                      <span>·</span>
                      <span>{p.scenes.length} scenes</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ── CTA footer ── */}
      <section className="px-6 py-16 text-center max-w-6xl mx-auto">
        <div className="glass rounded-3xl p-12 relative overflow-hidden">
          <div className="pointer-events-none absolute inset-0 -z-10">
            <div className="absolute left-1/2 bottom-0 -translate-x-1/2 h-64 w-64 bg-primary/15 blur-[80px]" />
          </div>
          <h2 className="text-3xl font-bold">Ready to create?</h2>
          <p className="mt-3 text-muted-foreground max-w-md mx-auto">
            Describe your video in plain English and let Aurora handle the rest.
          </p>
          <Link to="/create" className="mt-8 inline-block">
            <Button size="lg" className="glow text-base px-10 h-12 gap-2">
              <Zap className="h-5 w-5" />
              Start Creating
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
